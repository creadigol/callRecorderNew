package com.creadigol.callrecorder;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import de.hdodenhof.circleimageview.CircleImageView;

public class PlayActivityNew extends AppCompatActivity implements View.OnClickListener {
Toolbar toolbar;
    String path,number,contactName;
    int Callerid;
    private static String TAG="PLAY";
    ImageView iv_play,editnot,iv_call,iv_addcontact,iv_msg,backImage,iv_pause;
    String imagePath;
    CircleImageView profile_image;
    Context context;
    TextView state;
    String srcPath = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_new);
        iv_play=(ImageView)findViewById(R.id.iv_play);
        iv_pause=(ImageView)findViewById(R.id.iv_pause);
        iv_call=(ImageView)findViewById(R.id.iv_call);
        iv_addcontact=(ImageView)findViewById(R.id.iv_addcontact);
        iv_msg=(ImageView)findViewById(R.id.iv_msg);
        backImage=(ImageView)findViewById(R.id.backImage);
        profile_image=(CircleImageView) findViewById(R.id.profile_image);
        state = (TextView) findViewById(R.id.state);
        timeLine = (SeekBar) findViewById(R.id.seekbartimeline) ;
        timePos = (TextView)findViewById(R.id.pos);
        timeDur = (TextView)findViewById(R.id.dur);

        iv_play.setOnClickListener(this);
        iv_pause.setOnClickListener(this);
        iv_call.setOnClickListener(this);
        iv_addcontact.setOnClickListener(this);
        iv_msg.setOnClickListener(this);
        Intent intent=getIntent();
        path=intent.getStringExtra("path");
        number=intent.getStringExtra("number");
        Callerid=intent.getIntExtra("callerId",0);
        imagePath=intent.getStringExtra("imagePath");
        contactName=intent.getStringExtra("contactName");

        Log.e("Callerid",""+Callerid);
        Log.e("path",""+path);
        if(imagePath != null) {
            if (getContactBitmapFromURI(context, Uri.parse(imagePath)) != null) {
                profile_image.setImageBitmap(getContactBitmapFromURI(context, Uri.parse(imagePath)));
                backImage.setImageBitmap(getContactBitmapFromURI(context, Uri.parse(imagePath)));
            }
        }
        Toolbar();

        /*
        * player
        * */

        ScheduledExecutorService myScheduledExecutorService = Executors.newScheduledThreadPool(1);

        myScheduledExecutorService.scheduleWithFixedDelay(
                new Runnable(){
                    @Override
                    public void run() {
                        monitorHandler.sendMessage(monitorHandler.obtainMessage());
                    }},
                200, //initialDelay
                200, //delay
                TimeUnit.MILLISECONDS);
        srcPath = path;
//        info.setText(srcPath);

        cmdReset();
        cmdSetDataSource(srcPath);

    }



    public  Bitmap getContactBitmapFromURI(Context context, Uri uri) {
        InputStream input = null ;
        try {
            input = getContentResolver().openInputStream(uri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if (input == null) {
            return null;
        }
        return BitmapFactory.decodeStream(input);
    }
    public void Toolbar()
    {
        Toolbar toolbar = (Toolbar) findViewById(R.id.appbar_play);
        setSupportActionBar(toolbar);
        TextView tvCatTitle = (TextView) toolbar.findViewById(R.id.tv_toolbar_play);
        editnot=(ImageView)toolbar.findViewById(R.id.iv_edit);
        editnot.setOnClickListener(this);
        if(contactName != null) {
            tvCatTitle.setText(contactName);
        }else {
            tvCatTitle.setText(number);
        }
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            cmdStop();
            finish();
            // close this activity and return to preview activity (if there is any)
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        cmdStop();
        finish();
        // your code.
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.iv_play:
                iv_play.setVisibility(View.GONE);
                iv_pause.setVisibility(View.VISIBLE);

//                Intent ii = new Intent(getApplicationContext(), AndroidPlayerActivity.class);
//                ii.putExtra("path",path);
//                startActivity(ii);
                if(srcPath == null){
                    Toast.makeText(PlayActivityNew.this,
                            "No file selected",
                            Toast.LENGTH_LONG).show();
                }else{
                    cmdPrepare();
                    cmdStart();
                }

//                Context context = getApplicationContext();
//                Intent playIntent = new Intent(context, PlayService.class);
//                playIntent.putExtra(PlayService.EXTRA_FILENAME,path);
//                ComponentName name = context.startService(playIntent);
//                if (null == name) {
//                    Log.w(TAG, "CallLog unable to start PlayService with intent: " + playIntent.toString());
//                } else {
//                    Log.i(TAG, "CallLog started service: " + name);
//                }
                break;
            case R.id.iv_pause:
             iv_play.setVisibility(View.VISIBLE);
             iv_pause.setVisibility(View.GONE);
                cmdPause();
                break;
            case R.id.iv_edit:
                Intent i = new Intent(getApplicationContext(), Editnotes_activity.class);
                i.putExtra("callerId",Callerid);
                startActivity(i);
                break;
            case R.id.iv_call:
                callLog1();
                break;
            case R.id.iv_addcontact:
                Intent add = new Intent(
                        ContactsContract.Intents.SHOW_OR_CREATE_CONTACT,
                        Uri.parse("tel:" + number));
                add.putExtra(ContactsContract.Intents.EXTRA_FORCE_CREATE, true);
                startActivity(add);
                break;
            case R.id.iv_msg:
                Intent intentsms = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:"+number));
                intentsms.putExtra("sms_body", "text of massege");
                startActivity(intentsms);
                break;

        }
    }

    public void callLog1() {
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        startActivity(intent);
    }
/*
* player
* */
SeekBar timeLine;
//    LinearLayout timeFrame;
    TextView timePos, timeDur;

    final static int RQS_OPEN_AUDIO_MP3 = 1;

    MediaPlayer mediaPlayer;

    enum MP_State {
        Idle, Initialized, Prepared, Started, Paused,
        Stopped, PlaybackCompleted, End, Error, Preparing}

    AndroidPlayerActivity.MP_State mediaPlayerState;

    Handler monitorHandler = new Handler(){

        @Override
        public void handleMessage(Message msg) {
            mediaPlayerMonitor();
        }

    };

    private void mediaPlayerMonitor(){
        if (mediaPlayer == null){
            timeLine.setVisibility(View.INVISIBLE);
//            timeFrame.setVisibility(View.INVISIBLE);
        }else{
            if(mediaPlayer.isPlaying()){
                timeLine.setVisibility(View.VISIBLE);
//                timeFrame.setVisibility(View.VISIBLE);
                int mediaDuration = mediaPlayer.getDuration();
                int mediaPosition = mediaPlayer.getCurrentPosition();
                timeLine.setMax(mediaDuration);
                timeLine.setProgress(mediaPosition);
                timePos.setText(String.valueOf((float)mediaPosition/1000) + "s");
                timeDur.setText(String.valueOf((float)mediaDuration/1000) + "s");
            }else{
                iv_play.setVisibility(View.VISIBLE);
                iv_pause.setVisibility(View.GONE);
                timePos.setText("0:00");
//                timeLine.setVisibility(View.INVISIBLE);
//                timeFrame.setVisibility(View.INVISIBLE);
            }
        }
    }

    MediaPlayer.OnErrorListener mediaPlayerOnErrorListener
            = new MediaPlayer.OnErrorListener(){

        @Override
        public boolean onError(MediaPlayer mp, int what, int extra) {
            // TODO Auto-generated method stub

            mediaPlayerState = AndroidPlayerActivity.MP_State.Error;
            showMediaPlayerState();

            return false;
        }};


    private void cmdReset(){
        if (mediaPlayer == null){
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setOnErrorListener(mediaPlayerOnErrorListener);
        }
        mediaPlayer.reset();
        mediaPlayerState = AndroidPlayerActivity.MP_State.Idle;
        showMediaPlayerState();
    }

    private void cmdSetDataSource(String path){
        if(mediaPlayerState == AndroidPlayerActivity.MP_State.Idle){
            try {
                mediaPlayer.setDataSource(path);
                mediaPlayerState = AndroidPlayerActivity.MP_State.Initialized;
            } catch (IllegalArgumentException e) {
                Toast.makeText(PlayActivityNew.this,
                        e.toString(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            } catch (IllegalStateException e) {
                Toast.makeText(PlayActivityNew.this,
                        e.toString(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            } catch (IOException e) {
                Toast.makeText(PlayActivityNew.this,
                        e.toString(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }else{
//            Toast.makeText(PlayActivity.this,
//                    "Invalid State@cmdSetDataSource - skip",
//                    Toast.LENGTH_LONG).show();
        }

        showMediaPlayerState();
    }

    private void cmdPrepare(){

        if(mediaPlayerState == AndroidPlayerActivity.MP_State.Initialized
                ||mediaPlayerState == AndroidPlayerActivity.MP_State.Stopped){
            try {
                mediaPlayer.prepare();
                mediaPlayerState = AndroidPlayerActivity.MP_State.Prepared;
            } catch (IllegalStateException e) {
                Toast.makeText(PlayActivityNew.this,
                        e.toString(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            } catch (IOException e) {
                Toast.makeText(PlayActivityNew.this,
                        e.toString(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }else{
//            Toast.makeText(PlayActivity.this,
//                    "Invalid State@cmdPrepare() - skip",
//                    Toast.LENGTH_LONG).show();
        }

        showMediaPlayerState();
    }

    private void cmdStart(){
        if(mediaPlayerState == AndroidPlayerActivity.MP_State.Prepared
                ||mediaPlayerState == AndroidPlayerActivity.MP_State.Started
                ||mediaPlayerState == AndroidPlayerActivity.MP_State.Paused
                ||mediaPlayerState == AndroidPlayerActivity.MP_State.PlaybackCompleted){
            mediaPlayer.start();
            mediaPlayerState = AndroidPlayerActivity.MP_State.Started;
        }else{
//            Toast.makeText(PlayActivity.this,
//                    "Invalid State@cmdStart() - skip",
//                    Toast.LENGTH_LONG).show();
        }

        showMediaPlayerState();
    }

    private void cmdPause(){
        if(mediaPlayerState == AndroidPlayerActivity.MP_State.Started
                ||mediaPlayerState == AndroidPlayerActivity.MP_State.Paused){
            mediaPlayer.pause();
            mediaPlayerState = AndroidPlayerActivity.MP_State.Paused;
        }else{
//            Toast.makeText(PlayActivity.this,
//                    "Invalid State@cmdPause() - skip",
//                    Toast.LENGTH_LONG).show();
        }
        showMediaPlayerState();
    }

    private void cmdStop(){

        if(mediaPlayerState == AndroidPlayerActivity.MP_State.Prepared
                ||mediaPlayerState == AndroidPlayerActivity.MP_State.Started
                ||mediaPlayerState == AndroidPlayerActivity.MP_State.Stopped
                ||mediaPlayerState == AndroidPlayerActivity.MP_State.Paused
                ||mediaPlayerState == AndroidPlayerActivity.MP_State.PlaybackCompleted){
            mediaPlayer.stop();
            mediaPlayerState = AndroidPlayerActivity.MP_State.Stopped;
        }else{
//            Toast.makeText(PlayActivity.this,
//                    "Invalid State@cmdStop() - skip",
//                    Toast.LENGTH_LONG).show();
        }
        showMediaPlayerState();


    }

    private void showMediaPlayerState(){

        switch(mediaPlayerState){
            case Idle:
                state.setText("Idle");
                break;
            case Initialized:
                state.setText("Initialized");
                break;
            case Prepared:
                state.setText("Prepared");
                break;
            case Started:
                state.setText("Started");
                break;
            case Paused:
                state.setText("Paused");
                break;
            case Stopped:
                state.setText("Stopped");
                break;
            case PlaybackCompleted:
                state.setText("PlaybackCompleted");
                break;
            case End:
                state.setText("End");
                break;
            case Error:
                state.setText("Error");
                break;
            case Preparing:
                state.setText("Preparing");
                break;
            default:
                state.setText("Unknown!");
        }
    }

    View.OnClickListener buttonPlayOnClickListener
            = new View.OnClickListener(){

        @Override
        public void onClick(View v) {

            if(srcPath == null){
                Toast.makeText(PlayActivityNew.this,
                        "No file selected",
                        Toast.LENGTH_LONG).show();
            }else{
                cmdPrepare();
                cmdStart();
            }

        }

    };

    View.OnClickListener buttonPauseOnClickListener
            = new View.OnClickListener(){

        @Override
        public void onClick(View v) {
            cmdPause();
        }

    };

    View.OnClickListener buttonStopOnClickListener
            = new View.OnClickListener(){

        @Override
        public void onClick(View v) {

            cmdStop();

        }

    };

    View.OnClickListener buttonOpenOnClickListener
            = new View.OnClickListener(){

        @Override
        public void onClick(View arg0) {
            Intent intent = new Intent();
            intent.setType("audio/mp3");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(
                    intent, "Open Audio (mp3) file"), RQS_OPEN_AUDIO_MP3);

        }
    };

}
