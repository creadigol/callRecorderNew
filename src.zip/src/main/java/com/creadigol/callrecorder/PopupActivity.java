package com.creadigol.callrecorder;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.creadigol.callrecorder.Model.CallRecorderModel;
import com.creadigol.callrecorder.Utils.PreferenceSettings;
import com.creadigol.callrecorder.database.DatabaseHelper;

/**
 * Created by ADMIN on 10-Nov-16.
 */

public class PopupActivity extends Activity implements View.OnClickListener {
    TextView Add, Cancel;
    DatabaseHelper db;
    PreferenceSettings pref;
    String namee, image, save, number, type, dayofeweek, recording,CuurentTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popup);
        db = new DatabaseHelper(PopupActivity.this);
        pref = new PreferenceSettings(PopupActivity.this);
        Add = (TextView) findViewById(R.id.iv_true);
        Cancel = (TextView) findViewById(R.id.iv_false);
        Intent i = getIntent();
        namee = i.getStringExtra("name");
        image = i.getStringExtra("image");
        save = i.getStringExtra("save");
        number = i.getStringExtra("number");
        type = i.getStringExtra("type");
        dayofeweek = i.getStringExtra("dayoftheweek");
        recording = i.getStringExtra("recording");
        CuurentTime = i.getStringExtra("CuurentTime");
        Add.setOnClickListener(this);
        Cancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_true:
//                Toast.makeText(this, "true", Toast.LENGTH_SHORT).show();
                int value = db.getAllCallRecordDetail().size();
                int inboxSize = pref.getInboxSize();
                int minId = db.minCallerId();
                Log.e("database "+value,"min id"+db.minCallerId()  +"prefe " + inboxSize);
                if (value < inboxSize) {
                    insertInDatabase();
                }else {
                    db.deleteItem(minId);
                    insertInDatabase();

                }
                finish();
                break;

            case R.id.iv_false:
                finish();
                break;

            default:
                break;
        }
    }

    public void insertInDatabase() {

        Calendar c = Calendar.getInstance();
        Log.e("Currenttime" + c.getTime(), "");
        SimpleDateFormat df = new SimpleDateFormat("hh:mm:ss");
        String formattedDate = df.format(c.getTime());


        Date date1 = null;
        Date date2 = null;
        try {
            date1 = df.parse(CuurentTime);
            date2 = df.parse(formattedDate);


        } catch (ParseException e) {
            e.printStackTrace();
        }

        long difference = date2.getTime() - date1.getTime();
//        int days = (int) (difference / (1000 * 60 * 60 * 24));
//        int hours = (int) ((difference - (1000 * 60 * 60 * 24 * days)) / (1000 * 60 * 60));
//        int min = (int) (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours)) / (1000 * 60);
//        int sec = (int) (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours)) - (1000 * 60 * 60 * min) ;
//        hours = (hours < 0 ? -hours : hours);

        long diffSeconds = difference / 1000 % 60;
        long diffMinutes = difference / (60 * 1000) % 60;
        long diffHours = difference / (60 * 60 * 1000) % 24;
        Toast.makeText(getApplicationContext(), "" +diffHours + " days" +diffSeconds+ "min " + diffMinutes, Toast.LENGTH_LONG).show();


        CallRecorderModel callRecorderModel = new CallRecorderModel();
        callRecorderModel.setCallername(namee);
        callRecorderModel.setCallerimage(image);
        int value = db.getContactToSave(number).size();
        if(value > 0) {
            callRecorderModel.setSaved("true");
        }else {
            callRecorderModel.setSaved("false");

        }
        callRecorderModel.setDelete("false");
        String substr = number.substring(number.length() - 10);
        callRecorderModel.setCallernumber(substr);
        callRecorderModel.setType(type);
        callRecorderModel.setCallDuration(diffHours +":"+diffMinutes+":"+ diffSeconds );
        callRecorderModel.setUpload("false");
        callRecorderModel.setCallingtime(dayofeweek);
        callRecorderModel.setRecordingpath(String.valueOf(recording));

        db.insertCallRecorder(callRecorderModel);

    }
}
