package com.creadigol.callrecorder.callrecordersdata;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.provider.ContactsContract;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.google.android.gms.plus.model.people.Person;

import com.creadigol.callrecorder.Utils.PreferenceSettings;

public class CallBroadcastReceiver extends BroadcastReceiver {

    private String callerImageUrl = "", callerName = "";
    PreferenceSettings pref;
    private Context context;
    private static boolean isRing = false;

    @Override
    public void onReceive(Context context, Intent intent) {

        this.context = context;
        pref = new PreferenceSettings(context);
        String callerNumber = "";
        //We listen to two intents.  The new outgoing call only tells us of an outgoing call.  We use it to get the number.
        if (intent.getAction().equals("android.intent.action.NEW_OUTGOING_CALL")) {
            callerNumber = intent.getExtras().getString("android.intent.extra.PHONE_NUMBER");
        } else {
            String stateStr = intent.getExtras().getString(TelephonyManager.EXTRA_STATE);
            String number = intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
            callerNumber = number;
            int state = 0;
            if (stateStr.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                isRing = false;
                state = TelephonyManager.CALL_STATE_IDLE;
            } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                state = TelephonyManager.CALL_STATE_OFFHOOK;
            } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                isRing = true;
                state = TelephonyManager.CALL_STATE_RINGING;
            }
            Log.e("state", "state = "+ state);
            onCallStateChanged(context, state, number);
        }

        if (callerNumber != null && callerNumber.length() > 0) {
            getImage(callerNumber);
            getName(callerNumber);
        }
    }

    /*Deals with actual events
    Incoming call-  goes from IDLE to RINGING when it rings, to OFFHOOK when it's answered, to IDLE when its hung up
    Outgoing call-  goes from IDLE to OFFHOOK when it dials out, to IDLE when hung up*/
    public void onCallStateChanged(Context context, int state, String number) {

        switch (state) {
            case TelephonyManager.CALL_STATE_RINGING:
                Log.e("IN BC", "In ringging state");
                break;
            case TelephonyManager.CALL_STATE_OFFHOOK:
                //Transition of ringing->offhook are pickups of incoming calls.  Nothing done on them
                if (isRing) {
                    onCallStarted(context, number, true);
                } else {
                    onCallStarted(context, number, false);
                }
                break;
            case TelephonyManager.CALL_STATE_IDLE:
                //Went to idle-  this is the end of a call.  What type depends on previous state(s)
                if (isRing) {
                    //Ring but no pickup-  a miss
                    onCallEnded();
                } else {
                    onCallEnded();
                }
                break;
        }

    }

    //Derived classes should override these to respond to specific events of interest
    protected void onCallStarted(final Context ctx, final String number, final boolean isIncomingCall) {

        int delay = 0;
        Log.e("IN BC", "isIncomingCall :: "+ isIncomingCall);
        if (isIncomingCall) {
            delay = Integer.parseInt(pref.getDelayIncoming());
        } else {
            delay = Integer.parseInt(pref.getDelayOutgoing());
        }
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms
                Intent callIntent = new Intent(ctx, RecordService.class);
                callIntent.putExtra(RecordService.EXTRA_NUMBER, number);
                if (isIncomingCall)
                    callIntent.putExtra(RecordService.EXTRA_IS_INCOMING, true);
                else
                    callIntent.putExtra(RecordService.EXTRA_IS_INCOMING, false);
                callIntent.putExtra(RecordService.EXTRA_IMAGE_URL, callerImageUrl);
                callIntent.putExtra(RecordService.EXTRA_CONTACT_NAME, callerName);
                context.startService(callIntent);
            }
        }, delay * 1000);

        //isIncoming = false;
    }

    protected void onCallEnded() {
        Log.e("", "onCallEnded()");
        context.stopService(new Intent(context, RecordService.class));
    }

    public void getImage(String mobileNumber) {
        String imnage;
        Cursor phonesCursor = null;
        Person.Urls urls;
        // Get image from phone no
        try {
            Uri phoneUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(mobileNumber));
            phonesCursor = context.getContentResolver().query(phoneUri, new String[]{ContactsContract.PhoneLookup.PHOTO_THUMBNAIL_URI}, null, null, null);
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        if (phonesCursor != null && phonesCursor.moveToFirst()) {
            imnage = phonesCursor.getString(0);
            try {
                callerImageUrl = String.valueOf(Uri.parse(imnage));
                Log.e("phonelistener", "image path" + Uri.parse(imnage));
                Log.e("detail", "==============" + imnage);
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
            // displayName = phonesCursor.getString(0); // this is the contact callerName
        } else {
            Log.e("no contact ", "============");
        }
    }

    public void getName(String mobileNumber) {
        String image;
        Cursor phonesCursor = null;
        Person.Urls urls;
        // Get image from phone no
        try {
            Uri phoneUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(mobileNumber));
            phonesCursor = context.getContentResolver().query(phoneUri, new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        if (phonesCursor != null && phonesCursor.moveToFirst()) {
            image = phonesCursor.getString(0);
            try {
                callerName = String.valueOf(Uri.parse(image));
                Log.e("phonelistener", "contact callerName" + Uri.parse(callerName));
                Log.e("detail", "==============" + image);
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
        } else {
            Log.e("no contact ", "============");
        }
    }
}
