package com.creadigol.callrecorder.callrecordersdata;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.creadigol.callrecorder.Model.CallRecorderModel;
import com.creadigol.callrecorder.Utils.PreferenceSettings;

/**
 * Created by ADMIN on 24-Nov-16.
 */
public class NotificationBroadcast extends BroadcastReceiver {
    public static String numberToCall;
    PreferenceSettings pref;

    CallRecorderModel callRecorderModel = new CallRecorderModel();


    public void onReceive(Context context, Intent intent) {
        String action = (String) intent.getExtras().get("DO");
        String number = intent.getStringExtra("monumber");
        String type = intent.getStringExtra("type");
        pref = new PreferenceSettings(context);
        Log.e("notification", "notification" + action + number + type);
        if (action != null) {
            if (action.equals("start")) {
                pref.setAUTOSAVE_RECORDING(true);

                Log.d("CallRecorder", "CallBroadcastReceiver::onReceive got Intent: " + intent.toString());
                if (type.equalsIgnoreCase("outgoing")) {
                    pref.setAUTOSAVE_RECORDING(true);
                    numberToCall = number;
                    callRecorderModel.setCallernumber(numberToCall);
                    Log.d("CallRecorder", "CallBroadcastReceiver intent has EXTRA_PHONE_NUMBER: " + numberToCall);

                }

                PhoneListener phoneListener = new PhoneListener(context, number);
                TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
                telephony.listen(phoneListener, PhoneStateListener.LISTEN_CALL_STATE);
                Log.d("PhoneStateReceiver::onReceive", "set PhoneStateListener");
//            Toast.makeText(context, "auto", Toast.LENGTH_SHORT).show();
                Toast.makeText(context, "start", Toast.LENGTH_SHORT).show();

            } else if (action.equals("stop")) {
//                Toast.makeText(context, "outgoing", Toast.LENGTH_SHORT).show();

                Intent intentt = new Intent(context, RecordService.class);
                context.stopService(intentt);
            }
        }
    }


}
