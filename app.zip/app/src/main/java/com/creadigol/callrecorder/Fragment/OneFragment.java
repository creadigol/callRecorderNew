package com.creadigol.callrecorder.Fragment;

/**
 * Created by ADMIN on 17-Oct-16.
 */


import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersDecoration;

import java.util.ArrayList;
import java.util.WeakHashMap;

import com.creadigol.callrecorder.Adapter.InboxAdapter;
import com.creadigol.callrecorder.MainActivity;
import com.creadigol.callrecorder.Model.CallRecorderModel;
import com.creadigol.callrecorder.R;
import com.creadigol.callrecorder.database.DatabaseHelper;

public class OneFragment extends Fragment {
    private SwipeRefreshLayout refreshLayout;
    private boolean fadeHeader = true;
    private RecyclerView mListView;
    public static InboxAdapter adapter;
    public static ArrayList<CallRecorderModel> callRecorderModels = new ArrayList<>();
    DatabaseHelper db;
    WeakHashMap<View, Integer> mOriginalViewHeightPool = new WeakHashMap<View, Integer>();
    static RecyclerView recyclerView;
    public static Context context;

    public OneFragment() {

    }

    public OneFragment(Context context) {
        // Required empty public constructor
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }


    @Override
    public void onResume() {
        super.onResume();
        if (MainActivity.deleteFlag == true) {
            MainActivity.deleteFlag = false;
//    Intent intent = new Intent(getActivity(),MainActivity.class);
//    getActivity().finish();
//    startActivity(intent);
            Fragment frg = OneFragment.this;
//        frg = getFragmentManager().findFragmentByTag("INBOX");
            final FragmentTransaction ft = getFragmentManager().beginTransaction();
            Log.e("Size1", callRecorderModels.size() + " test");
            ft.detach(frg);
            ft.attach(frg);
            ft.commit();
            Log.e("Size1", callRecorderModels.size() + " test");
        }
        if (MainActivity.MultiDelete == true) {
            MainActivity.MultiDelete = false;
            Fragment frg = OneFragment.this;
            final FragmentTransaction ft = getFragmentManager().beginTransaction();
            ft.detach(frg);
            ft.attach(frg);
            ft.commit();
        }
//        Fragment frg = OneFragment.this;
//        final FragmentTransaction ft = getFragmentManager().beginTransaction();
//        ft.detach(frg);
//        ft.attach(frg);
//        ft.commit();
//        callRecorderModels.clear(); //clear list
//        setAdapter();
//        adapter.notifyDataSetChanged();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_one, container, false);
        // Inflate the layout for this fragment

        refreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.refresh_layout);
        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        refreshLayout.setRefreshing(false);
                        Fragment frg = OneFragment.this;
//        frg = getFragmentManager().findFragmentByTag("INBOX");
                        final FragmentTransaction ft = getFragmentManager().beginTransaction();
                        ft.detach(frg);
                        ft.attach(frg);
                        ft.commit();
                    }
                }, 1000);
            }
        });
        db = new DatabaseHelper(getActivity());
        recyclerView = (RecyclerView) view.findViewById(R.id.list);
//        adapter = new InboxAdapter(getContext());
//        callRecorderModels = new ArrayList<>();
//        callRecorderModels = db.getAllCallRecordDetail();
        setAdapter(db.getAllCallRecordDetail());
        return view;
    }

    public static void setAdapter(ArrayList<CallRecorderModel> test) {
//        recyclerView = (RecyclerView) findViewById(R.id.list);
        adapter = new InboxAdapter(context);
        callRecorderModels = new ArrayList<>();
        callRecorderModels = test;
        Log.e("Test", test.size() + " " + callRecorderModels.size());
//        callRecorderModels = db.getAllCallRecordDetail();

        if (callRecorderModels.size() > 0) {
            recyclerView.setVisibility(View.VISIBLE);
//            if(adapter==null) {
            LinearLayoutManager layoutManager = new LinearLayoutManager(context);
            recyclerView.setLayoutManager(layoutManager);
            //adapter.add("Animals below!");
            adapter.addAll(callRecorderModels);
            recyclerView.setAdapter(adapter);
            // Add the sticky headers decoration
            final StickyRecyclerHeadersDecoration headersDecor = new StickyRecyclerHeadersDecoration(adapter);
            recyclerView.addItemDecoration(headersDecor);
            // Add decoration for dividers between list items
//        recyclerView.addItemDecoration(new DividerDecoration(getActivity().getBaseContext()));

            adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
                @Override
                public void onChanged() {
                    headersDecor.invalidateHeaders();
                }
            });
//            }else{
//                adapter.modifyDataSet(callRecorderModels);
//            }
            //recyclerView.setOnClickListener();
        }
    }

}