package com.creadigol.callrecorder.Utils;

/**
 * Created by Vj on 12/16/2016.
 */

public interface Constants {

    /*constants for Ask before recording */
    public static final int SAVE_AFTER_EDIT_ASK_WHAT_TO_DO = 1;
    public static final int SAVE_AFTER_EDIT_SAVE = 2;
    public static final int SAVE_AFTER_EDIT_DONT_SAVE = 3;

    /*constants for default filters */
    public static final int FILTER_RECORD_ALL = 1;
    public static final int FILTER_IGNORE_ALL = 2;
    public static final int FILTER_IGNORE_CONTACTS = 3;

    public static final int AUDIO_FORMAT_3GP = 1;
    public static final int AUDIO_FORMAT_MP4 = 2;
    public static final int AUDIO_FORMAT_AMR = 3;
    public static final int AUDIO_FORMAT_FLAC = 4;
    public static final int AUDIO_FORMAT_WAV = 5;

}
