package com.creadigol.callrecorder;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ParseException;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import com.creadigol.callrecorder.Model.CallRecorderModel;

import de.hdodenhof.circleimageview.CircleImageView;

public class PlayActivityNew extends AppCompatActivity implements View.OnClickListener, SeekBar.OnSeekBarChangeListener {
    Toolbar toolbar;
    // String path,number,contactName;
    // int Callerid;
    private static String TAG = "PLAY";
    ImageView iv_play, editnot, iv_call, iv_addcontact, iv_msg, backImage, iv_pause;
    // String imagePath;
    CircleImageView profile_image;
    Context context;
    TextView state;
    String srcPath = null;
    CallRecorderModel callAudio;
    SeekBar mSeekBar;
    private Thread mSeekThread;
    private TextView tvCurrentPosition, tvDuration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_new);
        iv_play = (ImageView) findViewById(R.id.iv_play);
        iv_pause = (ImageView) findViewById(R.id.iv_pause);
        iv_call = (ImageView) findViewById(R.id.iv_call);
        iv_addcontact = (ImageView) findViewById(R.id.iv_addcontact);
        iv_msg = (ImageView) findViewById(R.id.iv_msg);
        backImage = (ImageView) findViewById(R.id.backImage);
        profile_image = (CircleImageView) findViewById(R.id.profile_image);
        state = (TextView) findViewById(R.id.state);
        mSeekBar = (SeekBar) findViewById(R.id.seekbartimeline);
        mSeekBar.setOnSeekBarChangeListener(this);
        tvCurrentPosition = (TextView) findViewById(R.id.pos);
        tvDuration = (TextView) findViewById(R.id.dur);

        iv_play.setOnClickListener(this);
        iv_pause.setOnClickListener(this);
        iv_call.setOnClickListener(this);
        iv_addcontact.setOnClickListener(this);
        iv_msg.setOnClickListener(this);

        callAudio = new CallRecorderModel();

        Intent intent = getIntent();
        String path = intent.getStringExtra("path");
        callAudio.setRecordingpath(path);
        String number = intent.getStringExtra("number");
        callAudio.setCallernumber(number);
        int Callerid = intent.getIntExtra("callerId", 0);
        callAudio.setCallerid(Callerid);
        String imagePath = intent.getStringExtra("imagePath");
        callAudio.setCallerimage(imagePath);
        String contactName = intent.getStringExtra("contactName");
        callAudio.setCallername(contactName);

        Log.e("Callerid", "" + Callerid);
        Log.e("path", "" + path);
        if (imagePath != null) {
            if (getContactBitmapFromURI(context, Uri.parse(imagePath)) != null) {
                profile_image.setImageBitmap(getContactBitmapFromURI(context, Uri.parse(imagePath)));
                backImage.setImageBitmap(getContactBitmapFromURI(context, Uri.parse(imagePath)));
            }
        }
        Toolbar();
    }

    private MusicService musicSrv;
    private Intent playIntent;
    private boolean musicBound = false;

    @Override
    protected void onStart() {
        super.onStart();
        if (playIntent == null) {
            playIntent = new Intent(this, MusicService.class);
            bindService(playIntent, musicConnection, Context.BIND_AUTO_CREATE);
            startService(playIntent);
        }
    }

    //connect to the service
    private ServiceConnection musicConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.MusicBinder binder = (MusicService.MusicBinder) service;
            //get service
            musicSrv = binder.getService();
            //pass list
            //musicSrv.setList(songList);
            musicSrv.setAudio(callAudio);
            musicBound = true;
            musicSrv.prepareSong();
            //setSeekBar();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            musicSrv = null;
            musicBound = false;
        }
    };

    public void startPlaying() {
        iv_play.setVisibility(View.GONE);
        iv_pause.setVisibility(View.VISIBLE);
        musicSrv.playSong();
        setSeekBar();
        startProgress();
    }

    public void pausePlaying() {
        iv_play.setVisibility(View.VISIBLE);
        iv_pause.setVisibility(View.GONE);
        musicSrv.paushPlayback(); //TODO Pause playback
        pauseProgress();
    }

    public void endPlayback() {
        if (playIntent != null) {
            stopService(playIntent);
            unbindService(musicConnection);
            musicSrv = null;
            playIntent = null;
        }
        //System.exit(0);
    }

    public void setSeekBar() {
        int mDuration = musicSrv.getDuration();
        Log.e("PlayActivity", "mDuration:" + mDuration);

        if (mDuration > 0) {
            mSeekBar.setMax(mDuration / 1000); // where mFileDuration is mMediaPlayer.getDuration();
            tvDuration.setText(millisecondToTime(mDuration));
        } else {
            // TODO player not prepare
        }

        tvDuration.setText(millisecondToTime(mDuration));
    }

    public void startProgress() {
        startPlayProgressUpdater();
    }

    public void pauseProgress() {
        if (mSeekThread != null)
            try {
                mSeekThread.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
    }

    private final Handler handler = new Handler();

    public void startPlayProgressUpdater() {
        int currentPosition = 0;
        if (musicSrv != null) {
            currentPosition = musicSrv.getCurrentPosition();
        } else {
            return;
        }
        Log.e("PlayActivity", "currentPosition:" + currentPosition);
        mSeekBar.setProgress(currentPosition / 1000);
        tvCurrentPosition.setText(millisecondToTime(currentPosition));

        if (musicSrv.isPlaying()) {
            Runnable notification = new Runnable() {
                public void run() {
                    startPlayProgressUpdater();
                }
            };
            handler.postDelayed(notification, 1000);
        } else {
//            mediaPlayer.pause();
//            buttonPlayStop.setText(getString(R.string.play_str));
            //mSeekBar.setProgress(0);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_play: // TODO play audio
                startPlaying();
                break;
            case R.id.iv_pause:
                pausePlaying();
                break;
            case R.id.iv_edit:
                Intent i = new Intent(getApplicationContext(), Editnotes_activity.class);
                i.putExtra("callerId", callAudio.getCallerid());
                startActivity(i);
                break;
            case R.id.iv_call:
                callLog1();
                break;
            case R.id.iv_addcontact:
                Intent add = new Intent(
                        ContactsContract.Intents.SHOW_OR_CREATE_CONTACT,
                        Uri.parse("tel:" + callAudio.getCallernumber()));
                add.putExtra(ContactsContract.Intents.EXTRA_FORCE_CREATE, true);
                startActivity(add);
                break;
            case R.id.iv_msg:
                Intent intentsms = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:" + callAudio.getCallernumber()));
                intentsms.putExtra("sms_body", "text of massege");
                startActivity(intentsms);
                break;
        }
    }

    /*public void songPicked(View view){
        musicSrv.setSong(Integer.parseInt(view.getTag().toString()));
        musicSrv.prepareSong();
    }*/

    @Override
    protected void onDestroy() {
        endPlayback();
        super.onDestroy();
    }

    public Bitmap getContactBitmapFromURI(Context context, Uri uri) {
        InputStream input = null;
        try {
            input = getContentResolver().openInputStream(uri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if (input == null) {
            return null;
        }
        return BitmapFactory.decodeStream(input);
    }


    public void Toolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.appbar_play);
        setSupportActionBar(toolbar);
        TextView tvCatTitle = (TextView) toolbar.findViewById(R.id.tv_toolbar_play);
        editnot = (ImageView) toolbar.findViewById(R.id.iv_edit);
        editnot.setOnClickListener(this);
        if (callAudio.getCallername() != null) {
            tvCatTitle.setText(callAudio.getCallername());
        } else {
            tvCatTitle.setText(callAudio.getCallernumber());
        }
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            endPlayback();
            finish();
            // close this activity and return to preview activity (if there is any)
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        endPlayback();
        finish();
        // your code.
    }


    public void callLog1() {
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + callAudio.getCallernumber()));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        startActivity(intent);
    }

    /**
     * Notification that the progress level has changed. Clients can use the fromUser parameter
     * to distinguish user-initiated changes from those that occurred programmatically.
     *
     * @param seekBar  The SeekBar whose progress has changed
     * @param progress The current progress level. This will be in the range 0..max where max
     *                 was set by {@link ProgressBar#setMax(int)}. (The default value for max is 100.)
     * @param fromUser True if the progress change was initiated by the user.
     */
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

    }

    /**
     * Notification that the user has started a touch gesture. Clients may want to use this
     * to disable advancing the seekbar.
     *
     * @param seekBar The SeekBar in which the touch gesture began
     */
    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    /**
     * Notification that the user has finished a touch gesture. Clients may want to use this
     * to re-enable advancing the seekbar.
     *
     * @param seekBar The SeekBar in which the touch gesture began
     */
    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        Log.e("PlayActivity", "seekBar.getProgress(): " + seekBar.getProgress());
        musicSrv.shiftPlayback(seekBar.getProgress());
    }

    public String millisecondToTime(long millseconds) throws ParseException {
        //long millis = 3600000;
        String hms = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(millseconds),
                TimeUnit.MILLISECONDS.toMinutes(millseconds) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millseconds)),
                TimeUnit.MILLISECONDS.toSeconds(millseconds) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millseconds)));
        System.out.println(hms);
        return hms;
    }
}
