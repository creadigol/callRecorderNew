package com.creadigol.callrecorder.Adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersAdapter;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;
import com.creadigol.callrecorder.DetailActivity;
import com.creadigol.callrecorder.Model.CallRecorderModel;
import com.creadigol.callrecorder.R;
import com.creadigol.callrecorder.Utils.PreferenceSettings;


import android.graphics.Color;

import com.creadigol.callrecorder.MainActivity;
import com.creadigol.callrecorder.database.DatabaseHelper;


/**
 * Created by Vj on 8/2/2016.
 */

public class InboxAdapter extends MyTAdapter<RecyclerView.ViewHolder> implements StickyRecyclerHeadersAdapter<RecyclerView.ViewHolder> {
    public Context context;
    String time, callduration;
    String callingNumber, callingTime, recordingPath;
    Integer CallerId;
    ArrayList<CallRecorderModel> callRecorderModels;
    String pathh;
    DatabaseHelper databaseHelper;
    PreferenceSettings mPreferenceSettings;

    public InboxAdapter(Context context) {

        this.context = context;
    }

    public static Bitmap getContactBitmapFromURI(Context context, Uri uri) {
        InputStream input = null;
        try {
            input = context.getContentResolver().openInputStream(uri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if (input == null) {
            return null;
        }
        return BitmapFactory.decodeStream(input);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.test_list_item_layout, parent, false);
        Date dt = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm aa");
        time = sdf.format(dt);
        TagViewHolder tagViewHolder = new TagViewHolder(view);
        return tagViewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        mPreferenceSettings = new PreferenceSettings(context);
        final TagViewHolder tagViewHolder = (TagViewHolder) holder;
        databaseHelper = new DatabaseHelper(context);
        CallRecorderModel myTagsObject = getItem(position);
        CallerId = myTagsObject.getCallerid();
        callingTime = myTagsObject.getHeaderDate();
        recordingPath = myTagsObject.getRecordingpath();


        if (myTagsObject.getCallername() != null && myTagsObject.getCallername().length() > 0) {
            tagViewHolder.name.setText(myTagsObject.getCallername());
            callingNumber = myTagsObject.getCallername();
        } else {
            if (!myTagsObject.getCallernumber().equalsIgnoreCase("0")) {
//                tagViewHolder.name.setText("+91 " + myTagsObject.getCallernumber());
                tagViewHolder.name.setText("0" + myTagsObject.getCallernumber());
                callingNumber = String.valueOf((myTagsObject.getCallernumber()));
            } else {

            }
        }

//        if (myTagsObject.getCallernumber() != 0) {
//
//            tagViewHolder.name.setText("+91 " + myTagsObject.getCallernumber());
//            callingNumber = String.valueOf((myTagsObject.getCallernumber()));
//            Log.e("numbercondition", "" + callingNumber);
//        } else {
//            tagViewHolder.name.setText(myTagsObject.getCallername());
//            callingNumber = myTagsObject.getCallername();
//        }

        Log.e("", "myTagsObject.getType() "+myTagsObject.getType());
        if (myTagsObject.getType() != null) {
            if (myTagsObject.getType().equalsIgnoreCase(DatabaseHelper.CALL_TYPE_INCOMING)) {
                tagViewHolder.callinfoLogo.setImageResource(R.drawable.redarrow);
            } else if (myTagsObject.getType().equalsIgnoreCase(DatabaseHelper.CALL_TYPE_OUTGOING)) {
                tagViewHolder.callinfoLogo.setImageResource(R.drawable.greenarrow);
            }
        } else {

        }


        Log.e("InboxAdapter", "" + myTagsObject.getCallerimage());
//        setProfileImage(tagViewHolder,myTagsObject.getCallerimage());
        pathh = myTagsObject.getCallerimage();
//        Log.e("Bitmap decode",getContactBitmapFromURI(context, Uri.parse(myTagsObject.getCallerimage()))  + " test " + myTagsObject.getCallerimage());
        if (pathh != null) {
            Bitmap bitmap = getContactBitmapFromURI(context, Uri.parse(myTagsObject.getCallerimage()));
            if (bitmap != null)
                tagViewHolder.profile_image.setImageBitmap(bitmap);
            else
                tagViewHolder.profile_image.setImageResource(R.drawable.contact);
        } else {
            tagViewHolder.profile_image.setImageResource(R.drawable.contact);

        }

        if (mPreferenceSettings.getDriveLogin() == true) {
            if (myTagsObject.getSaved().equalsIgnoreCase("true")) {
                tagViewHolder.cloudButton.setVisibility(View.VISIBLE);
                if (myTagsObject.getUpload().equalsIgnoreCase("true")) {
                    tagViewHolder.cloudImage.setImageResource(R.drawable.seenicon);
                } else {
                    tagViewHolder.cloudImage.setImageResource(R.drawable.cloudered);
                }
            }
        }

        tagViewHolder.cloudButton.setTag(position);
        tagViewHolder.cloudButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = (int) v.getTag();
                CallRecorderModel myTagsObject = getItem(position);
                if (myTagsObject.getUpload().equalsIgnoreCase("false")) {
                    MainActivity.saveFiletoDrive(myTagsObject.getRecordingpath());
                    Toast.makeText(context, "" + myTagsObject.getRecordingpath(), Toast.LENGTH_SHORT).show();
                    tagViewHolder.cloudButton.setClickable(false);
                    tagViewHolder.cloudImage.setImageResource(R.drawable.seenicon);

                    databaseHelper.UpdateCloudStatus(myTagsObject.getCallerid(), "true");
                } else {
                    Toast.makeText(context, "Already uploaded this audio ", Toast.LENGTH_SHORT).show();
                }
            }
        });
//        CallrecorderApplication.getInstance().getImageLoader().displayImage(myTagsObject.getCallerimage(), tagViewHolder.profile_image, getDisplayImageOptions());
//        tagViewHolder.profile_image.setImageResource(R.drawable.playpink);
//        if(myTagsObject.getCallingtime()!=null)
//        {
//            tagViewHolder.date.setText("" + myTagsObject.getCallingdate());
//        }
//        long temp = Long.parseLong(myTagsObject.getTransactionDate());
////
//        long currentTimeLong = System.currentTimeMillis(); // will get you current time in milli
//        long difference = currentTimeLong - temp;
//        String strDiff = String.valueOf(difference);
//        tagViewHolder.date.setText(strDiff);
        tagViewHolder.date.setText(myTagsObject.getTransactionDate());
        tagViewHolder.duration.setText(myTagsObject.getCallDuration());
        tagViewHolder.ll_mainlist.setTag(position);
        tagViewHolder.ll_mainlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = (int) v.getTag();
                CallRecorderModel myTagsObject = getItem(position);
                Log.e("data", " id " + myTagsObject.getCallerid() + " number " + myTagsObject.getCallernumber() + " date " + myTagsObject.getTransactionDate() + "");
                String path = myTagsObject.getCallerimage();

                if (myTagsObject.getDelete().equalsIgnoreCase("true")) {
                    databaseHelper.UpadetDeleteStatus(myTagsObject.getCallerid(), "false");
                    myTagsObject.setDelete("false");
                    MainActivity.toolbar.setVisibility(View.VISIBLE);
                    MainActivity.toolbar_delete.setVisibility(View.GONE);
                    tagViewHolder.linear_main.setBackgroundColor(Color.parseColor("#ffffff"));
                    if (path != null) {
                        tagViewHolder.profile_image.setImageBitmap(getContactBitmapFromURI(context, Uri.parse(myTagsObject.getCallerimage())));
                    } else {
                        tagViewHolder.profile_image.setImageResource(R.drawable.contact);
                    }
                } else {
                    Intent intent = new Intent(context, DetailActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("position", position);
                    intent.putExtra("CallerId", myTagsObject.getCallerid());
                    intent.putExtra("Callerdate", myTagsObject.getTransactionDate());
                    intent.putExtra("callingNumber", myTagsObject.getCallernumber());
                    intent.putExtra("recordingPath", myTagsObject.getRecordingpath());
                    intent.putExtra("contactImage", myTagsObject.getCallerimage());
                    intent.putExtra("contactName", myTagsObject.getCallername());
                    intent.putExtra("save", myTagsObject.getSaved());
                    context.startActivity(intent);
                }
            }
        });
        tagViewHolder.profile_image.setTag(position);
        tagViewHolder.profile_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = (int) v.getTag();
                CallRecorderModel myTagsObject = getItem(position);
                String path = myTagsObject.getCallerimage();


                if (myTagsObject.getDelete().equalsIgnoreCase("false")) {
                    myTagsObject.setDelete("true");
                    databaseHelper.UpadetDeleteStatus(myTagsObject.getCallerid(), "true");
                    tagViewHolder.profile_image.setImageResource(R.drawable.mark);
                    tagViewHolder.linear_main.setBackgroundColor(Color.parseColor("#e2d7d8"));

                    MainActivity.delete.add(myTagsObject.getCallerid());

                    databaseHelper.UpdatesaveStatus(myTagsObject.getCallerid(), "true");

                    Toast.makeText(context, "id==" + myTagsObject.getCallerid(), Toast.LENGTH_SHORT).show();

                } else if (myTagsObject.getDelete().equalsIgnoreCase("true")) {
                    databaseHelper.UpadetDeleteStatus(myTagsObject.getCallerid(), "false");
                    myTagsObject.setDelete("false");
                    tagViewHolder.linear_main.setBackgroundColor(Color.parseColor("#ffffff"));
                    if (path != null) {
                        tagViewHolder.profile_image.setImageBitmap(getContactBitmapFromURI(context, Uri.parse(myTagsObject.getCallerimage())));
                    } else {
                        tagViewHolder.profile_image.setImageResource(R.drawable.contact);
                    }
                    databaseHelper.UpdatesaveStatus(myTagsObject.getCallerid(), "false");
                    MainActivity.delete.remove(MainActivity.delete.indexOf(myTagsObject.getCallerid()));
                }
                if (MainActivity.delete != null) {
                    if (MainActivity.delete.size() > 0) {
                        MainActivity.toolbar.setVisibility(View.GONE);
                        MainActivity.toolbar_delete.setVisibility(View.VISIBLE);
                    } else {
                        MainActivity.toolbar.setVisibility(View.VISIBLE);
                        MainActivity.toolbar_delete.setVisibility(View.GONE);
                    }
                }


            }
        });
    }

    @Override
    public long getHeaderId(int position) {
//      if (position == 0) {
//        return -1;
//      } else {
//        return Long.parseLong(getItem(position).getCallingtime());
        return getItem(position).getDate();
//      }
    }

    @Override
    public RecyclerView.ViewHolder onCreateHeaderViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_header, parent, false);

        TagHeaderViewHolder tagHeaderViewHolder = new TagHeaderViewHolder(view);
        return tagHeaderViewHolder;
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder, int position) {
        TagHeaderViewHolder tagHeaderViewHolder = (TagHeaderViewHolder) holder;
        tagHeaderViewHolder.headerDay.setText(getItem(position).getCallingtime());
        tagHeaderViewHolder.headerDate.setText(getItem(position).getHeaderDate());
    }

    public void modifyDataSet(ArrayList<CallRecorderModel> searchObjects) {
        this.callRecorderModels = searchObjects;
        this.notifyDataSetChanged();
    }

    public class TagViewHolder extends RecyclerView.ViewHolder {
        TextView date;
        TextView name;
        TextView address, duration;
        ImageView callinfoLogo, cloudImage;
        CircleImageView profile_image;
        LinearLayout linear_main, ll_mainlist, cloudButton;

        public TagViewHolder(View itemView) {
            super(itemView);
            this.name = (TextView) itemView.findViewById(R.id.username);
            this.date = (TextView) itemView.findViewById(R.id.date);
            this.duration = (TextView) itemView.findViewById(R.id.duration);
            this.linear_main = (LinearLayout) itemView.findViewById(R.id.ll_calllist);
            this.cloudButton = (LinearLayout) itemView.findViewById(R.id.cloudButton);
            this.ll_mainlist = (LinearLayout) itemView.findViewById(R.id.ll_mainlist);
            this.callinfoLogo = (ImageView) itemView.findViewById(R.id.callinfoLogo);
            this.cloudImage = (ImageView) itemView.findViewById(R.id.cloudImage);
            this.profile_image = (CircleImageView) itemView.findViewById(R.id.caller_pic);
        }
    }


    public class TagHeaderViewHolder extends RecyclerView.ViewHolder {
        TextView headerDay;
        TextView headerDate;

        public TagHeaderViewHolder(View itemView) {
            super(itemView);
            this.headerDay = (TextView) itemView.findViewById(R.id.tv_header_day);
            this.headerDate = (TextView) itemView.findViewById(R.id.tv_header_date);
        }
    }

}
