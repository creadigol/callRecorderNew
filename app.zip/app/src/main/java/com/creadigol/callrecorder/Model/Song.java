package com.creadigol.callrecorder.Model;

/**
 * Created by Vj on 12/20/2016.
 */

public class Song {

    String path = "";

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

}
