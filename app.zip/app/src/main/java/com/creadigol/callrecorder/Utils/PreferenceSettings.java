package com.creadigol.callrecorder.Utils;

/**
 * Created by ravi on 26-10-2016.
 */

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;

public class PreferenceSettings {
    private String CASHTAG = "CashTag";

    private String WIFI_ONLY = "wifi";
    private String AUTOSAVE = "save";
    private String AUTOSAVE_RECORDING = "auto";

    private String PRE_NOTIFY_NEW_CALL = "newcall";
    private String SHOW_IMAGE_NOTIFY = "showcall";
    private String PRE_NOTIFY_AFTER_CALL = "aftercall";

    private final String SAVE_RECORDING = "saveRecording";

    private final String PRE_ON_GOING_CALL = "on_going_call";
    private final String PRE_ON_GOING_RECORDING = "on_going_recording";

    private final String AUDIO_FORMAT = "audio_format";
    private final String PRE_INBOX_SIZE = "inbox";
    private final String PRE_FILTER_MODE = "default2";
    private final String RECORDING_AUTOMATIC_SPEAKER = "speaker";
    private final String RECORDING_BLUETOOTH = "bluetooth";
    private final String RECORDING_VOLUMES = "volume";
    private final String RECORDING_PATH = "path";

    private final String DELAY_INCOMING = "incoming";
    private final String DELAY_OUTGOING = "outgoing";
    private final String DRIVELOGIN = "drivelogin";


    Context _context;

    private SharedPreferences sp;
    private SharedPreferences.Editor editor;


    public PreferenceSettings(Context context) {
        this._context = context;
        sp = _context.getSharedPreferences(CASHTAG, context.MODE_PRIVATE);
        editor = sp.edit();
    }

    public void setSaveAfterEditMode(int save) {
        editor.putInt(SAVE_RECORDING, save).commit();
    }

    public int getSaveAfterEditMode() {
        return sp.getInt(SAVE_RECORDING, Constants.SAVE_AFTER_EDIT_SAVE);
    }

    /////////////////////////////////////////////// setting record calls////////////////////////////////////////
    public void setRecordingSpeaker(String speaker) {
        editor.putString(RECORDING_AUTOMATIC_SPEAKER, speaker).commit();
    }

    public String getRecordingSpeaker() {
        return sp.getString(RECORDING_AUTOMATIC_SPEAKER, "");
    }

    /////////////////////////////////////////////// setting recordng bluetooth////////////////////////////////////////
    public void setRecordingBluetooth(String bluetooth) {
        editor.putString(RECORDING_BLUETOOTH, bluetooth).commit();
    }

    public String getRecordingBluetooth() {
        return sp.getString(RECORDING_BLUETOOTH, "");
    }

    /////////////////////////////////////////////// setting recordng volumes////////////////////////////////////////
    public void setRecordingVolumes(String volumes) {
        editor.putString(RECORDING_VOLUMES, volumes).commit();
    }

//    public String getRecordingVolumes() {
//        return sp.getString(RECORDING_VOLUMES, "");
//    }

    /*/////selular data///
    public void setSelularData(String selularData) {
        editor.putString(SELULAR_DATA, selularData).commit();
    }

    public String getSelularData() {
        return sp.getString(SELULAR_DATA, "");
    }

    public boolean getSELULARDATA_WARNIG() {
        return sp.getBoolean(SELULARDATA_WARNIG, false);
    }

    public void setSELULARDATA_WARNIG(boolean flag) {
        editor.putBoolean(SELULARDATA_WARNIG, flag).commit();
    }*/

    public boolean getWifionly() {
        return sp.getBoolean(WIFI_ONLY, false);
    }

    public void setWifionly(boolean flag) {
        editor.putBoolean(WIFI_ONLY, flag).commit();
    }

    public boolean getAUTOSAVE() {
        return sp.getBoolean(AUTOSAVE, false);
    }

    public void setAUTOSAVE(boolean flag) {
        editor.putBoolean(AUTOSAVE, flag).commit();
    }

    public boolean getSHOW_IMAGE_NOTIFY() {
        return sp.getBoolean(SHOW_IMAGE_NOTIFY, false);
    }

    public void setSHOW_IMAGE_NOTIFY(boolean flag) {
        editor.putBoolean(SHOW_IMAGE_NOTIFY, flag).commit();
    }


///////////////// ////////////////////////

    public void setDelayIncoming(String incoming) {
        editor.putString(DELAY_INCOMING, incoming).commit();
    }

    public String getDelayIncoming() {
        return sp.getString(DELAY_INCOMING, "3");
    }


    public void setDelayOutgoing(String outgoing) {
        editor.putString(DELAY_OUTGOING, outgoing).commit();
    }

    public String getDelayOutgoing() {
        return sp.getString(DELAY_OUTGOING, "3");
    }

    public boolean getDriveLogin() {
        return sp.getBoolean(DRIVELOGIN, false);
    }

    public void setDriveLogin(boolean flag) {
        editor.putBoolean(DRIVELOGIN, flag).commit();
    }


    /*public void setCallDuration(String duration) {
        editor.putString(DURATION, duration).commit();
    }

    public String getCallDuration() {
        return sp.getString(DURATION, "0");
    }*/


    /***************************
     * Recording Audio Format
     ****************************/
    public void setAudioFormat(int value) {
        editor.putInt(AUDIO_FORMAT, value).commit();
    }

    public int getAudioFormat() {
        return sp.getInt(AUDIO_FORMAT, Constants.AUDIO_FORMAT_3GP);
    }

    /*************************
     * inbox size
     *************************/
    public void setInboxSize(int value) {
        editor.putInt(PRE_INBOX_SIZE, value).commit();
    }

    public int getInboxSize() {
        return sp.getInt(PRE_INBOX_SIZE, 100);
    }

    /************************
     * Filter Default mode
     ************************/
    public void setFilterMode(int value) {
        editor.putInt(PRE_FILTER_MODE, value).commit();
    }

    public int getFilterMode() {
        return sp.getInt(PRE_FILTER_MODE, 1);
    }

    /***********************
     * Set application running or not
     ***********************/
    public boolean getAppStatus() {
        return sp.getBoolean(AUTOSAVE_RECORDING, true);
    }

    public void setAppStatus(boolean flag) {
        editor.putBoolean(AUTOSAVE_RECORDING, flag).commit();
    }

    /***********************
     * Set recording path
     ***********************/
    public void setRecordingPath(String save) {
        editor.putString(RECORDING_PATH, save).commit();
    }

    public String getRecordingPath() {
        return sp.getString(RECORDING_PATH, Environment.getExternalStorageDirectory().getPath() + "CallRecorder"); /*"/sdcard/callrecorder"*/
    }

    /***********************
     * Set After call notification enable or not
     ***********************/
    public boolean getNotifyAfterCall() {
        return sp.getBoolean(PRE_NOTIFY_AFTER_CALL, false);
    }

    public void setNotifyAfterCall(boolean flag) {
        editor.putBoolean(PRE_NOTIFY_AFTER_CALL, flag).commit();
    }


    /***********************
     * Set New call notification enable or not
     ***********************/
    public boolean getNotifyNewCall() {
        return sp.getBoolean(PRE_NOTIFY_NEW_CALL, true);
    }

    public void setNotifyNewCall(boolean flag) {
        editor.putBoolean(PRE_NOTIFY_NEW_CALL, flag).commit();
    }

    /***********************
     * Set Call is running or not
     ***********************/
    public boolean getIsCallRunning() {
        return sp.getBoolean(PRE_ON_GOING_CALL, false);
    }

    public void setIsCallRunning(boolean flag) {
        editor.putBoolean(PRE_ON_GOING_CALL, flag).commit();
    }

    /***********************
     * Set Recording running or not
     ***********************/
    public boolean getIsRecordingRunning() {
        return sp.getBoolean(PRE_ON_GOING_RECORDING, false);
    }

    public void setIsRecordingRunning(boolean flag) {
        editor.putBoolean(PRE_ON_GOING_RECORDING, flag).commit();
    }
}