package com.creadigol.callrecorder;

import android.app.Service;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.os.PowerManager;
import android.support.annotation.Nullable;
import android.util.Log;

import com.creadigol.callrecorder.Model.CallRecorderModel;

/**
 * Created by Vj on 12/20/2016.
 */

public class MusicService extends Service implements MediaPlayer.OnPreparedListener, MediaPlayer.OnErrorListener,
        MediaPlayer.OnCompletionListener {
    /**
     * Return the communication channel to the service.  May return null if
     * clients can not bind to the service.  The returned
     * {@link IBinder} is usually for a complex interface
     * that has been <a href="{@docRoot}guide/components/aidl.html">described using
     * aidl</a>.
     * <p>
     * <p><em>Note that unlike other application components, calls on to the
     * IBinder interface returned here may not happen on the main thread
     * of the process</em>.  More information about the main thread can be found in
     * <a href="{@docRoot}guide/topics/fundamentals/processes-and-threads.html">Processes and
     * Threads</a>.</p>
     *
     * @param intent The Intent that was used to bind to this service,
     * as given to {@link Context#bindService
     * Context.bindService}.  Note that any extras that were included with
     * the Intent at that point will <em>not</em> be seen here.
     * @return Return an IBinder through which clients can call on to the
     * service.
     */

    private MediaPlayer player;
    private boolean isPlayerPrepared = false;

    CallRecorderModel callAudio;

    private final IBinder musicBind = new MusicBinder();

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return musicBind;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        player.stop();
        player.release();
        return false;
    }

    public void onCreate() {
        //create the service
        super.onCreate();
        //create player
        player = new MediaPlayer();
        initMusicPlayer();
    }

    public void initMusicPlayer() {
        //set player properties
        player.setWakeMode(getApplicationContext(),
                PowerManager.PARTIAL_WAKE_LOCK);
        player.setAudioStreamType(AudioManager.STREAM_MUSIC);
        player.setOnPreparedListener(this);
        player.setOnCompletionListener(this);
        player.setOnErrorListener(this);
    }

    /*public void setList(ArrayList<Song> theSongs){
        songs=theSongs;
    }*/

    public void setAudio(CallRecorderModel callAudio) {
        this.callAudio = callAudio;
    }

    public class MusicBinder extends Binder {
        MusicService getService() {
            return MusicService.this;
        }
    }

    /*public void setSong(int songIndex){
        songPosn=songIndex;
    }*/

    public void prepareSong() {
        //play a song
        player.reset();
        //set uri
        Uri trackUri = Uri.parse(callAudio.getRecordingpath());
        try {
            player.setDataSource(getApplicationContext(), trackUri);
        } catch (Exception e) {
            Log.e("MUSIC SERVICE", "Error setting data source", e);
        }
        player.prepareAsync();
        isPlayerPrepared = true;
    }

    public int getDuration() {
        if (isPlayerPrepared)
            return player.getDuration();
        else
            return 0;
    }

    public int getCurrentPosition() {
        if (isPlayerPrepared) {
            int mCurrentPosition = player.getCurrentPosition();
            return mCurrentPosition;
        } else
            return 0;
    }

    public boolean isPlaying() {
        if (isPlayerPrepared) {
            return player.isPlaying();
        } else
            return false;
    }

    public void playSong() {
        if (isPlayerPrepared)
            player.start();
    }

    public void paushPlayback() {
        if (isPlayerPrepared) {
            player.pause();
        }
    }

    public void shiftPlayback(int pos) {
        if (isPlayerPrepared) {
            pos = pos * 1000;
            player.seekTo(pos);
            Log.e("PlayActivity", "shiftPlayback: "+ pos * 100);
        }
    }

    /*public void resumePlayback(){
        if(isPlayerPrepared){
            player.start();
        }
    }*/

    /**
     * Called when the end of a media source is reached during playback.
     *
     * @param mp the MediaPlayer that reached the end of the file
     */
    @Override
    public void onCompletion(MediaPlayer mp) {

    }

    /**
     * Called to indicate an error.
     */
    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        return false;
    }

    /**
     * Called when the media file is ready for playback.
     */
    @Override
    public void onPrepared(MediaPlayer mp) {
        //start playback

    }
}
