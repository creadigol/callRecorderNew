package com.creadigol.callrecorder.Adapter;

import java.util.ArrayList;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.creadigol.callrecorder.Model.CallRecorderModel;
import com.creadigol.callrecorder.R;

public class CallHistoryAdapter extends RecyclerView.Adapter<ViewHolder> {

	
	private static Context context;
	ArrayList<CallRecorderModel> callRecorderModels;
	OnClickListener onClickListener;

	public CallHistoryAdapter(Context context,
			ArrayList<CallRecorderModel> callRecorderModels) {
		// TODO Auto-generated constructor stub
		this.context = context;
		this.callRecorderModels = callRecorderModels;

	}

	@Override
	public int getItemCount() {
		// TODO Auto-generated method stub
		return callRecorderModels.size();
	}

	@Override
	public void onBindViewHolder(ViewHolder viewHolder,
			final int position) {
		// TODO Auto-generated method stub
		final TextFeedViewHolder holder = (TextFeedViewHolder) viewHolder;
//String number = String.valueOf(callRecorderModels.get(position).getCallernumber());
//		holder.number.setText(number);

		if (!callRecorderModels.get(position).getCallernumber().equalsIgnoreCase("0")) {
			holder.number.setText("+91 " + callRecorderModels.get(position).getCallernumber());


		} else {
			holder.number.setText(callRecorderModels.get(position).getCallername());

		}

		holder.date.setText(callRecorderModels.get(position).getTransactionDate().toString());
		if (callRecorderModels.get(position).getType() != null) {
			if (callRecorderModels.get(position).getType().equalsIgnoreCase("incoming")) {
				holder.callinfoLogo.setImageResource(R.drawable.redarrow);
			} else if(callRecorderModels.get(position).getType().equalsIgnoreCase("outgoing")) {
				holder.callinfoLogo.setImageResource(R.drawable.greenarrow);
			}
		} else {

		}


	}

	@Override
	public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
		// TODO Auto-generated method stub

		final View view = LayoutInflater.from(context).inflate(
				R.layout.test_list_item_layout, parent, false);

		final TextFeedViewHolder textFeedViewHolder = new TextFeedViewHolder(
				view);

		return textFeedViewHolder;

	}

	public static class TextFeedViewHolder extends ViewHolder {
		TextView number,date;
		ImageView callinfoLogo;

		
		public TextFeedViewHolder(View view) {
			super(view);

			number = (TextView) view.findViewById(R.id.username);
			date = (TextView) view.findViewById(R.id.date);
			callinfoLogo = (ImageView) view.findViewById(R.id.callinfoLogo);

		}
	}
}
