package com.creadigol.callrecorder.views;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;

import com.creadigol.callrecorder.R;
import com.creadigol.callrecorder.NotificationBroadcast;
import com.creadigol.callrecorder.callrecordersdata.RecordService;

/**
 * Created by Vj on 12/22/2016.
 */

public class RemoteControlWidget extends RemoteViews {
    private final Context mContext;

    public static final String ACTION_START = "com.creadigol.callrecorder.ACTION_START";
    public static final String ACTION_STOP = "com.creadigol.callrecorder.ACTION_STOP";
    public static final String ACTION_OPEN_APP = "com.creadigol.callrecorder.ACTION_OPEN_APP";

    public RemoteControlWidget(Context context, String packageName, int layoutId, boolean needActionButton, String number, boolean isIncoming) {
        super(packageName, layoutId);
        mContext = context;
        Intent intent;
        PendingIntent pendingIntent;

        if (needActionButton) {
            setViewVisibility(R.id.btn_record, View.VISIBLE);

            intent = new Intent(mContext, NotificationBroadcast.class);
            intent.setAction(ACTION_START);
            intent.putExtra(RecordService.EXTRA_NUMBER, number);
            intent.putExtra(RecordService.EXTRA_IS_INCOMING, isIncoming);
            pendingIntent = PendingIntent.getBroadcast(mContext.getApplicationContext(), 101,
                    intent, PendingIntent.FLAG_UPDATE_CURRENT);
            setOnClickPendingIntent(R.id.btn_record, pendingIntent);
        } else {
            setViewVisibility(R.id.btn_record, View.GONE);
/*
            intent = new Intent(context, NotificationBroadcast.class);
            intent.setAction(ACTION_START);
            intent.putExtra(RecordService.EXTRA_NUMBER, number);
            intent.putExtra(RecordService.EXTRA_IS_INCOMING, isIncoming);
            pendingIntent = PendingIntent.getService(mContext.getApplicationContext(), 101,
                    intent, PendingIntent.FLAG_UPDATE_CURRENT);
            setOnClickPendingIntent(R.id.btn_record, pendingIntent);*/
        }
        /*if(appStatus){
            intent = new Intent(context, NotificationBroadcast.class);
            intent.setAction(ACTION_STOP);
            intent.putExtra("DO", "stop");
            pendingIntent = PendingIntent.getService(mContext.getApplicationContext(),101,
                    intent,PendingIntent.FLAG_UPDATE_CURRENT);
            setOnClickPendingIntent(R.id.stopBtn,pendingIntent);
        } else {*/

        /*}*/
    }
}
