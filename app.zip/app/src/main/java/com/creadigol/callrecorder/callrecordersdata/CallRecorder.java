package com.creadigol.callrecorder.callrecordersdata;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.provider.ContactsContract;
import android.util.Log;

import com.creadigol.callrecorder.R;
import com.creadigol.callrecorder.Utils.Common;
import com.creadigol.callrecorder.Utils.CustomNotification;
import com.creadigol.callrecorder.Utils.PreferenceSettings;
import com.google.android.gms.plus.model.people.Person;

/**
 * Created by Vj on 12/23/2016.
 */

public class CallRecorder {

    private Context  mContext;
    private PreferenceSettings pref;
    public CallRecorder(Context context) {
        mContext = context;
        pref = new PreferenceSettings(mContext);
    }

    //Derived classes should override these to respond to specific events of interest
    public void onCallStarted(final String number, final boolean isIncomingCall) {

        int delay = 0;
        Log.e("IN BC", "isIncomingCall :: "+ isIncomingCall);
        if (isIncomingCall) {
            delay = Integer.parseInt(pref.getDelayIncoming());
        } else {
            delay = Integer.parseInt(pref.getDelayOutgoing());
        }
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms
                Intent callIntent = new Intent(mContext, RecordService.class);
                callIntent.putExtra(RecordService.EXTRA_NUMBER, number);
                if (isIncomingCall)
                    callIntent.putExtra(RecordService.EXTRA_IS_INCOMING, true);
                else
                    callIntent.putExtra(RecordService.EXTRA_IS_INCOMING, false);
                callIntent.putExtra(RecordService.EXTRA_IMAGE_URL, Common.getContactImage(mContext, number));
                callIntent.putExtra(RecordService.EXTRA_CONTACT_NAME, Common.getContactName(mContext, number));
                mContext.startService(callIntent);

                CustomNotification customNotification = new CustomNotification(mContext);
                customNotification.sendNotification(true,
                        false,
                        mContext.getResources().getString(R.string.app_name),
                        mContext.getResources().getString(R.string.recording),
                        number,
                        isIncomingCall, false);

            }
        }, delay * 1000);

        //isIncoming = false;
    }

    public void onCallEnded() {
        Log.e("", "onCallEnded()");
        mContext.stopService(new Intent(mContext, RecordService.class));
    }

}
