package com.creadigol.callrecorder.callrecordersdata;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import com.creadigol.callrecorder.MainActivity;
import com.creadigol.callrecorder.Model.CallRecorderModel;
import com.creadigol.callrecorder.R;
import com.creadigol.callrecorder.Utils.Common;
import com.creadigol.callrecorder.Utils.Constants;
import com.creadigol.callrecorder.Utils.CustomNotification;
import com.creadigol.callrecorder.Utils.PreferenceSettings;
import com.creadigol.callrecorder.database.DatabaseHelper;

public class RecordService extends Service implements MediaRecorder.OnInfoListener, MediaRecorder.OnErrorListener {
    private static final String TAG = "RecordService";
    private static final int RECORDING_NOTIFICATION_ID = 1;

    public static final String EXTRA_NUMBER = "caller_number";
    public static final String EXTRA_IS_INCOMING = "is_incoming";
    public static final String EXTRA_IMAGE_URL = "image_url";
    public static final String EXTRA_CONTACT_NAME = "contact_name";

    public static String DEFAULT_STORAGE_LOCATION = "";
    static String a = null;
    static String tempName = null;
    String callerNumber, imageUrl, contactName;
    boolean isIncoming;
    String prefix;
    String recordingDate, dayoftheweek;
    DatabaseHelper db;
    PreferenceSettings pref;
    AudioManager audioManager;
    Boolean CheckName = false;
    String CuurentTime;
    RemoteViews contentView;
    private MediaRecorder mRecorder = null;
    private boolean isRecording = false;
    private File recording = null;
    private NotificationCompat.Builder builder;
    private int audioSource = MediaRecorder.AudioSource.VOICE_CALL;

    public void onCreate() {
        super.onCreate();

        mRecorder = new MediaRecorder();
        db = new DatabaseHelper(getApplicationContext());
        pref = new PreferenceSettings(RecordService.this);
        DEFAULT_STORAGE_LOCATION = pref.getRecordingPath();
        Log.i("CallRecorder", "onCreate created MediaRecorder object");
        String enableSpeaker = pref.getRecordingSpeaker();

        Log.e(TAG, "Preference enable speaker value : " + enableSpeaker);
        if (enableSpeaker.equals("true")) {
            audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            audioManager.setMode(AudioManager.MODE_IN_CALL);
            audioManager.setSpeakerphoneOn(true);
        }
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////
        BluetoothAdapter bluetooth = BluetoothAdapter.getDefaultAdapter();
        String blue = pref.getRecordingBluetooth();
        if (bluetooth.isEnabled()) {
            if (blue.equals("true")) {
                stopSelf();
            }
        }
    }

    public void onStart(Intent intent, int startId) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        prefix = sdf.format(new Date());
        recordingDate = sdf.format(new Date());
        try {
            callerNumber = intent.getStringExtra(EXTRA_NUMBER);
            isIncoming = intent.getBooleanExtra(EXTRA_IS_INCOMING, true);

            Log.e("RecordService", "callerNumber " + callerNumber);
            imageUrl = intent.getStringExtra(EXTRA_IMAGE_URL);
            contactName = intent.getStringExtra(EXTRA_CONTACT_NAME);

            if (imageUrl != null)
                a = imageUrl;

            if (contactName != null)
                tempName = contactName;
        } catch (Exception e) {

        }

        /*
        * For off automatic recording
        * */

        Log.i("CallRecorder", "RecordService::onStartCommand called while isRecording:" + isRecording);
        Context c = getApplicationContext();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(c);

        /*
        * For Stop Recording
        * */
        if (pref.getAppStatus()) {
            Log.e("AUTOSAVE_RECORDING()", "prefff" + pref.getAppStatus());
            Boolean shouldRecord = pref.getAppStatus();

            if (shouldRecord == false) {
                Log.i("CallRecord", "RecordService::onStartCommand with PREF_RECORD_CALLS false, not recording");
                return;
            }
        }

        recording = makeOutputFile(prefs);
        if (recording == null) {
            mRecorder = null;
            return; //return 0;
        }

        int audioFormat = pref.getAudioFormat();
        //Log.i("CallRecorder", "RecordService will config MediaRecorder with audiosource: " + audioSource + " audioformat: " + audioformat);
        try {
            // These calls will throw exceptions unless you set the
            // android.permission.RECORD_AUDIO permission for your app
            prepareMediaRecorder(audioSource, audioFormat, recording.getAbsolutePath());
            startRecording();
            //pref.setIsRecordingRunning(true);
            Log.e("CallRecorder", "Call Recording start.");
        } catch (java.lang.Exception e) {
            try {
                prepareMediaRecorder(MediaRecorder.AudioSource.MIC, audioFormat, recording.getAbsolutePath());
                startRecording();

                Log.e("CallRecorder", "Mic Recording start.");
            } catch (Exception e1) {
                //pref.setIsRecordingRunning(false);
                e1.printStackTrace();
                Toast t = Toast.makeText(getApplicationContext(), "CallRecorder was unable to start recording: ", Toast.LENGTH_LONG);
                t.show();
                Log.e("CallRecorder", "Exeption on Mic recording", e);
                mRecorder = null;
            }
            Log.e("CallRecorder", "Exeption on Call recording", e);
        }

        return; //return 0; //return START_STICKY;
    }

    private File makeOutputFile(SharedPreferences prefs) {
        File dir = new File(DEFAULT_STORAGE_LOCATION);

        // test dir for existence and writeability
        if (!dir.exists()) {
            try {
                dir.mkdirs();
            } catch (Exception e) {
                Log.e("CallRecorder", "RecordService::makeOutputFile unable to create directory " + dir + ": " + e);
                Toast t = Toast.makeText(getApplicationContext(), "CallRecorder was unable to create the directory " + dir + " to store recordings: " + e, Toast.LENGTH_LONG);
                t.show();
                return null;
            }
        } else {
            if (!dir.canWrite()) {
                Log.e(TAG, "RecordService::makeOutputFile does not have write permission for directory: " + dir);
                Toast t = Toast.makeText(getApplicationContext(), "CallRecorder does not have write permission for the directory directory " + dir + " to store recordings", Toast.LENGTH_LONG);
                t.show();
                return null;
            }
        }

        // create filename based on call data
        SimpleDateFormat sdf = new SimpleDateFormat("dd");
        prefix = sdf.format(new Date());
        recordingDate = sdf.format(new Date());

        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);
        Calendar calendar = Calendar.getInstance();
        dayoftheweek = dayFormat.format(calendar.getTime());
        Log.e("day", "" + dayoftheweek);

        prefix += "-channel" + audioSource + "-";
        // create suffix based on format
        String suffix = "";
        switch (pref.getAudioFormat()) {
            case Constants.AUDIO_FORMAT_3GP:
                suffix = ".3gpp";
                break;
            case Constants.AUDIO_FORMAT_MP4:
                suffix = ".m4a";
                break;
            case Constants.AUDIO_FORMAT_AMR:
                suffix = ".amr";
                break;
            case Constants.AUDIO_FORMAT_FLAC:
                suffix = ".flac";
                break;
            case Constants.AUDIO_FORMAT_WAV:
                suffix = ".wav";
                break;
        }

        try {
            return File.createTempFile(prefix, suffix, dir);
        } catch (IOException e) {
            Log.e("CallRecorder", "RecordService::makeOutputFile unable to create temp file in " + dir + ": " + e);
            return null;
        }
    }

    public void startRecording() throws Exception {
        mRecorder.start();

        isRecording = true;

        Boolean newCall = pref.getNotifyNewCall();
        Log.i("CallRecorder", "mRecorder.start() returned" + newCall);

        Calendar cal = Calendar.getInstance();
        Log.e("Currenttime" + cal.getTime(), "");
        SimpleDateFormat df = new SimpleDateFormat("hh:mm:ss");
        String formattedDate = df.format(cal.getTime());
        CuurentTime = formattedDate;
        pref.setIsRecordingRunning(true);
        /*if (newCall == true) {
            updateNotification(true);
        }*/
    }

    public MediaRecorder prepareMediaRecorder(int audioSource, int audioformat, String recordingPath) throws IOException {

        mRecorder.reset();
        mRecorder.setAudioSource(audioSource);
        if(audioformat == Constants.AUDIO_FORMAT_3GP){
            mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        } else if(audioformat == Constants.AUDIO_FORMAT_MP4){
            mRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        } else if(audioformat == Constants.AUDIO_FORMAT_AMR){
            mRecorder.setOutputFormat(MediaRecorder.OutputFormat.AMR_NB);
            mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        } else if(audioformat == Constants.AUDIO_FORMAT_FLAC){

        } else if(audioformat == Constants.AUDIO_FORMAT_WAV){

        }
        mRecorder.setOutputFile(recordingPath);

        mRecorder.setOnInfoListener(this);
        mRecorder.setOnErrorListener(this);

        mRecorder.prepare();
        return mRecorder;
    }

    public void onDestroy() {
        super.onDestroy();
        // TODO save in database
        boolean callRecorded = pref.getIsRecordingRunning();
        Log.e("callRecorded", "callRecorded" + callRecorded);
        pref.setIsRecordingRunning(false);

        if (null != mRecorder) {
            insertInDatabase();
            Log.i("CallRecorder", "RecordService::onDestroy calling mRecorder.release()");
            isRecording = false;
            mRecorder.release();
            Log.e("RecordService", "path" + recording + "  " + recordingDate);
        }

        Context mContext = this.getApplicationContext();
        if(callRecorded) {
            Log.e("callRecorded", " in callRecorded");
            String callerName = Common.getContactName(mContext, callerNumber);
            if(callerName == null || callerName.length() <= 0){
                callerName = callerNumber;
            }
            CustomNotification customNotification = new CustomNotification(mContext);
            customNotification.sendNotification(false,
                    false,
                    mContext.getResources().getString(R.string.recorded_call),
                    callerName,
                    callerNumber,
                    isIncoming, false);
        } else {
            Log.e("callRecorded", " in not callRecorded");
            String callerName = Common.getContactName(mContext, callerNumber);
            if(callerName == null || callerName.length() <= 0){
                callerName = callerNumber;
            }
            CustomNotification customNotification = new CustomNotification(mContext);
            customNotification.sendNotification(false,
                    false,
                    mContext.getResources().getString(R.string.recorded_call),
                    callerName,
                    callerNumber,
                    isIncoming, true);
        }
        /*Boolean newCall = pref.getNotifyNewCall();
        if (newCall == true) {
            updateNotification(false);
        } else {
            String number = null;
            if (callerNumber != null && !callerNumber.isEmpty() && !callerNumber.equals("null"))
                number = callerNumber.substring(callerNumber.length() - 10);
            if (pref.getFilterMode() == Constants.FILTER_RECORD_ALL)
                RecordingAll(number);
            else if (pref.getFilterMode() == Constants.FILTER_IGNORE_ALL)
                RecordingSelected(number);
            else if (pref.getFilterMode() == Constants.FILTER_IGNORE_CONTACTS) {
                int size = db.getRecordUser(number).size();
                if (size > 0) {
                    RecordingSelected(number);
                    CheckName = true;
                }
                if (CheckName == false) {
                    if (tempName == null)
                        RecordingSelected(number);
                }
            }
        }*/
    }

    /*public void RecordingAll(String number) {
        int size = db.getBlockUser(number).size();
        Log.e("sizee", "sizee" + size + " n0" + number);
        if (size == 0) {
            if (pref.getSaveAfterEditMode() == Constants.SAVE_AFTER_EDIT_ASK_WHAT_TO_DO) {
//                showDialog();
                Intent intent = new Intent(RecordService.this, PopupActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("callerName", tempName);
                intent.putExtra("image", a);
                intent.putExtra("CuurentTime", CuurentTime);
                intent.putExtra("save", "false");
                if (callerNumber != null && !callerNumber.isEmpty() && !callerNumber.equals("null")) {
                    intent.putExtra("number", callerNumber);
                    if (isIncoming)
                        intent.putExtra("type", DatabaseHelper.CALL_TYPE_INCOMING);
                    else
                        intent.putExtra("type", DatabaseHelper.CALL_TYPE_OUTGOING);
                }
                intent.putExtra("dayoftheweek", dayoftheweek);
                intent.putExtra("recording", String.valueOf(recording));
                startActivity(intent);

            } else if (pref.getSaveAfterEditMode() == Constants.SAVE_AFTER_EDIT_SAVE) {
                int value = db.getAllCallRecordDetail().size();
                int minId = db.minCallerId();
                int inboxSize = pref.getInboxSize();
                Log.e("database " + value, "min id" + db.minCallerId() + "prefe " + inboxSize);
                if (value < inboxSize) {
                    insertInDatabase();
                } else {
                    db.deleteItem(minId);
                    insertInDatabase();
                }
            } else if (pref.getSaveAfterEditMode() == Constants.SAVE_AFTER_EDIT_DONT_SAVE) {
//                Toast.makeText(RecordService.this, "dont", Toast.LENGTH_SHORT).show();
            }

            Boolean afterCall = pref.getNotifyAfterCall();
            if (afterCall == true) {
                endCallNotification();
            }
        }
    }*/
    // methods to handle binding the service

//    public void RecordingSelected(String number) {
//        int size = db.getRecordUser(number).size();
//        Log.e("sizee", "sizee" + size + " n0" + number);
////        if (size > 0) {
//        if (pref.getSaveAfterEditMode() == Constants.SAVE_AFTER_EDIT_ASK_WHAT_TO_DO) {
////                showDialog();
//            Intent intent = new Intent(RecordService.this, PopupActivity.class);
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            intent.putExtra("callerName", tempName);
//            intent.putExtra("image", a);
//            intent.putExtra("save", "false");
//            intent.putExtra("CuurentTime", CuurentTime);
//            if (callerNumber != null && !callerNumber.isEmpty() && !callerNumber.equals("null")) {
//                intent.putExtra("number", callerNumber);
//                if (isIncoming)
//                    intent.putExtra("type", DatabaseHelper.CALL_TYPE_INCOMING);
//                else
//                    intent.putExtra("type", DatabaseHelper.CALL_TYPE_OUTGOING);
//            }
//            intent.putExtra("dayoftheweek", dayoftheweek);
//            intent.putExtra("recording", String.valueOf(recording));
//            startActivity(intent);
//        } else if (pref.getSaveAfterEditMode() == Constants.SAVE_AFTER_EDIT_SAVE) {
//            int value = db.getAllCallRecordDetail().size();
//            int minId = db.minCallerId();
//            int inboxSize = pref.getInboxSize();
//            Log.e("database " + value, "min id" + db.minCallerId() + "prefe " + inboxSize);
//            if (value < inboxSize) {
//                insertInDatabase();
//            } else {
//                db.deleteItem(minId);
//                insertInDatabase();
//            }
//        } else if (pref.getSaveAfterEditMode() == Constants.SAVE_AFTER_EDIT_DONT_SAVE) {
////                Toast.makeText(RecordService.this, "dont", Toast.LENGTH_SHORT).show();
//        }
//
//        Boolean afterCall = pref.getNotifyAfterCall();
//        if (afterCall == true) {
//            endCallNotification();
//        }
////        }
//    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public boolean onUnbind(Intent intent) {
        return false;
    }

    public void onRebind(Intent intent) {
    }

    /*public void updateNotification(Boolean status) {

        Context c = getApplicationContext();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(c);

        String ns = Context.NOTIFICATION_SERVICE;
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(ns);
        builder = new NotificationCompat.Builder(
                this);
        if (status) {
            int icon = R.drawable.ellipse;
//            CharSequence tickerText = " call from channel " + prefs.getString("1", "1");
            CharSequence tickerText = "Call Recorder";
            long when = System.currentTimeMillis();

            Notification notification = new Notification(icon, tickerText, when);

            Context context = getApplicationContext();
            CharSequence contentTitle = "CallRecorder Status";
            CharSequence contentText = "Recording";
            Intent notificationIntent = new Intent(this, RecordService.class);
            PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
            contentView = new RemoteViews(getPackageName(), R.layout.notification_layout);
//            notification.setLatestEventInfo(context, contentTitle, contentText, contentIntent);
////set the button listeners

            if (pref.getAppStatus() == false) {
                contentView.setViewVisibility(R.id.btn_record, View.VISIBLE);
            }*//* else {
                contentView.setViewVisibility(R.id.stopBtn, View.VISIBLE);
            }*//*

            Log.e("contentViewzad", "contentView" + contentView);
            setListeners(contentView);

            notification.contentView = contentView;
            notification.flags |= Notification.FLAG_ONGOING_EVENT;
//            notification = builder.setContentIntent(contentIntent)
//                    .setSmallIcon(R.drawable.ellipse).setTicker(contentTitle)
//                    .setAutoCancel(true).setContentTitle(contentText)
//                    .setContentText(contentText).build();
            mNotificationManager.notify(RECORDING_NOTIFICATION_ID, notification);
        } else {

            mNotificationManager.cancel(RECORDING_NOTIFICATION_ID);
            Boolean shouldRecord = pref.getAppStatus();
            if (shouldRecord == true) {
                String number = null;
                if (callerNumber != null && !callerNumber.isEmpty() && !callerNumber.equals("null")) {
//                    number = Strincoming;
                    number = callerNumber.substring(callerNumber.length() - 10);
                }


                if (pref.getFilterMode() == Constants.FILTER_RECORD_ALL) {
                    RecordingAll(number);
                } else if (pref.getFilterMode() == Constants.FILTER_IGNORE_ALL) {
                    RecordingSelected(number);
                } else if (pref.getFilterMode() == Constants.FILTER_IGNORE_CONTACTS) {
                    int size = db.getRecordUser(number).size();
                    Log.e("recorde", "zzz1" + size);

                    if (size > 0) {
                        RecordingSelected(number);
                        CheckName = true;
                    }

                    if (CheckName == false) {
                        if (tempName == null) {
                            RecordingSelected(number);
                        }
                    }
                }

            }
            Boolean afterCall = pref.getNotifyAfterCall();
            if (afterCall == true) {
                endCallNotification();
            }
        }
    }*/

    //
    /*public void setListeners(RemoteViews view) {
        //TODO screencapture listener
        Intent radio = new Intent(RecordService.this, NotificationBroadcast.class);
        radio.putExtra("DO", "start");
        String type = null;

        if (callerNumber != null && !callerNumber.isEmpty() && !callerNumber.equals("null")) {
            radio.putExtra("monumber", callerNumber);
        }

        if (isIncoming)
            type = DatabaseHelper.CALL_TYPE_INCOMING;
        else
            type = DatabaseHelper.CALL_TYPE_OUTGOING;

        radio.putExtra("type", type);
        PendingIntent pRadio = PendingIntent.getBroadcast(RecordService.this, 0, radio, 0);
        view.setOnClickPendingIntent(R.id.btn_record, pRadio);
        *//************************************************************************************//*
        //TODO screen size listener
//        Intent volume = new Intent(RecordService.this, NotificationBroadcast.class);
//        volume.putExtra("DO", "stop");
//        PendingIntent pVolume = PendingIntent.getBroadcast(RecordService.this, 1, volume, 0);
//        view.setOnClickPendingIntent(R.id.stopBtn, pVolume);

        Log.e("RecordService", "service click");

    }*/

    /*private void endCallNotification() {
        Context c = getApplicationContext();
        db = new DatabaseHelper(getBaseContext());
        int value = db.getAllCallRecordDetail().size();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(c);

        String ns = Context.NOTIFICATION_SERVICE;
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(ns);
        builder = new NotificationCompat.Builder(
                this);
        int icon = R.drawable.grayuser;
//            CharSequence tickerText = " call from channel " + prefs.getString("1", "1");
        CharSequence tickerText = "Call Recorder";
        long when = System.currentTimeMillis();

        Notification notification = new Notification(icon, tickerText, when);

        Context context = getApplicationContext();
        CharSequence contentTitle = "New Recording";
        CharSequence contentText = "You have " + value + " new recording in inbox.";
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);

        notification = builder.setContentIntent(contentIntent)
                .setSmallIcon(R.drawable.ellipse).setTicker(contentTitle)
                .setAutoCancel(true).setContentTitle(contentTitle)
                .setContentText(contentText).build();
        mNotificationManager.notify(RECORDING_NOTIFICATION_ID, notification);
    }*/

    // MediaRecorder.OnInfoListener
    public void onInfo(MediaRecorder mr, int what, int extra) {
        Log.i("CallRecorder", "RecordService got MediaRecorder onInfo callback with what: " + what + " extra: " + extra);
        isRecording = false;
    }

    // MediaRecorder.OnErrorListener
    public void onError(MediaRecorder mr, int what, int extra) {
        Log.e("CallRecorder", "RecordService got MediaRecorder onError callback with what: " + what + " extra: " + extra);
        isRecording = false;
        mr.release();
    }

    public void insertInDatabase() {
        Calendar c = Calendar.getInstance();
        Log.e("Currenttime" + c.getTime(), "");
        SimpleDateFormat df = new SimpleDateFormat("hh:mm:ss");
        String formattedDate = df.format(c.getTime());
        Date date1 = null;
        Date date2 = null;
        try {
            date1 = df.parse(CuurentTime);
            date2 = df.parse(formattedDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        long difference = date2.getTime() - date1.getTime();
        long diffSeconds = difference / 1000 % 60;
        long diffMinutes = difference / (60 * 1000) % 60;
        long diffHours = difference / (60 * 60 * 1000) % 24;

        MainActivity.deleteFlag = true;
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);
        Calendar calendar = Calendar.getInstance();
        dayoftheweek = dayFormat.format(calendar.getTime());
        Log.e("day", "" + dayoftheweek);

        Log.e("RecordService", "callerNumber" + callerNumber);
        CallRecorderModel callRecorderModel = new CallRecorderModel();
        callRecorderModel.setCallername(tempName);
        callRecorderModel.setCallerimage(a);
        Log.e("callRecorderModel", "inserted" + tempName);

        callRecorderModel.setDelete("false");
        callRecorderModel.setUpload("false");
//        retrieveContactPhoto();
        Log.e("outgoingNumber", "zzz" + callerNumber);
        Log.e("substring", "zzz" + callerNumber);
        if (callerNumber != null && !callerNumber.isEmpty() && !callerNumber.equals("null")) {
            String substr2 = callerNumber.substring(callerNumber.length() - 10);
            callRecorderModel.setCallernumber(substr2);
        }

        String callType = "";
        if (isIncoming)
            callType = DatabaseHelper.CALL_TYPE_INCOMING;
        else
            callType = DatabaseHelper.CALL_TYPE_OUTGOING;

        callRecorderModel.setType(callType);
        Log.e(TAG, "callType == " + callType);
//      callRecorderModel.setTransactionDate("1470220846862");
//      Log.e("myCurrentTimeMillis","myCurrentTimeMillis"+ String.valueOf(myCurrentTimeMillis));
        callRecorderModel.setCallingtime(dayoftheweek);
//      Toast.makeText(getApplicationContext(), "" +diffHours + " days" +diffSeconds+ "min " + diffMinutes, Toast.LENGTH_LONG).show();
        callRecorderModel.setCallDuration(diffHours + ":" + diffMinutes + ":" + diffSeconds);
        callRecorderModel.setRecordingpath(String.valueOf(recording));
        int value = db.getContactToSave(callerNumber).size();
        if (value > 0) {
            callRecorderModel.setSaved("true");
        } else {
            callRecorderModel.setSaved("false");
        }
        Log.e("contactosave", "" + value);
        db.insertCallRecorder(callRecorderModel);
        String autosaveTocloud = String.valueOf(pref.getAUTOSAVE()) + "";
        if (autosaveTocloud.equalsIgnoreCase("true")) {
            if (pref.getDriveLogin()) {
                Intent myIntent2 = new Intent(RecordService.this, AutoSaveToCloudService.class);
                startService(myIntent2);
            } else {
//                Toast.makeText(RecordService.this, "Please login in google drive", Toast.LENGTH_SHORT).show();
            }
        }

        stopSelf();

    }
}
