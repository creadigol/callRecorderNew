package com.creadigol.callrecorder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.creadigol.callrecorder.callrecordersdata.CallRecorder;
import com.creadigol.callrecorder.callrecordersdata.RecordService;
import com.creadigol.callrecorder.views.RemoteControlWidget;

/**
 * Created by ADMIN on 24-Nov-16.
 */
public class NotificationBroadcast extends BroadcastReceiver {

    public void onReceive(Context context, Intent intent) {
        Log.e("NotificationBroadcast","onReceive");
        CallRecorder callRecorder = new CallRecorder(context.getApplicationContext());
        if (intent.getAction().equals(RemoteControlWidget.ACTION_START)) {
            Log.e("NotificationBroadcast","Action Start");
            String number = intent.getStringExtra(RecordService.EXTRA_NUMBER);
            boolean isIncomingCall = intent.getBooleanExtra(RecordService.EXTRA_IS_INCOMING, true);
            callRecorder.onCallStarted(number, isIncomingCall);
            // TODO Update notification
        } else if(intent.getAction().equals(RemoteControlWidget.ACTION_STOP)){
            // TODO stop recording
            Log.e("NotificationBroadcast","Action Stop");
            // TODO Update notification
        }

    }


}
