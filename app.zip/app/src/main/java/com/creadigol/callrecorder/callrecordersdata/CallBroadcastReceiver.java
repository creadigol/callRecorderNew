package com.creadigol.callrecorder.callrecordersdata;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.creadigol.callrecorder.R;
import com.creadigol.callrecorder.Utils.CustomNotification;
import com.creadigol.callrecorder.database.DatabaseHelper;

import com.creadigol.callrecorder.Utils.PreferenceSettings;

public class CallBroadcastReceiver extends BroadcastReceiver {

    PreferenceSettings pref;
    private Context mContext;
    private static boolean isIncomming = false;

    @Override
    public void onReceive(Context context, Intent intent) {

        this.mContext = context.getApplicationContext();
        pref = new PreferenceSettings(mContext);
        String callerNumber = "";
        //We listen to two intents.  The new outgoing call only tells us of an outgoing call.  We use it to get the number.
        if (intent.getAction().equals("android.intent.action.NEW_OUTGOING_CALL")) {
            callerNumber = intent.getExtras().getString("android.intent.extra.PHONE_NUMBER");
            pref.setIsCallRunning(true);
//            Toast.makeText(mContext, "Outgoing", Toast.LENGTH_LONG).show();
        } else {
            String stateStr = intent.getExtras().getString(TelephonyManager.EXTRA_STATE);
            String number = intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
            callerNumber = number;

            /*Check app is running or not.*/
            if(!pref.getAppStatus())
                return;

            int state = 0;
            if (stateStr.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                isIncomming = false;
                pref.setIsCallRunning(false);
                state = TelephonyManager.CALL_STATE_IDLE;
            } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                pref.setIsCallRunning(true);
                state = TelephonyManager.CALL_STATE_OFFHOOK;
            } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                pref.setIsCallRunning(true);
                isIncomming = true;
                state = TelephonyManager.CALL_STATE_RINGING;
            }

            /*Check need to record for this number or not*/
            DatabaseHelper databaseHelper = new DatabaseHelper(mContext);
            if(!databaseHelper.needToRecord(callerNumber, pref.getFilterMode()) && !pref.getIsRecordingRunning()){
                // notification with recording button
                CustomNotification customNotification = new CustomNotification(mContext);
                customNotification.sendNotification(true,
                        true,
                        mContext.getResources().getString(R.string.app_name),
                        mContext.getResources().getString(R.string.not_recording_ignoring),
                        callerNumber,
                        isIncomming, false);
                return;
            }
            Log.e("state", "state = "+ state);
            onCallStateChanged(mContext, state, number);
        }
    }

    /*Deals with actual events
    Incoming call-  goes from IDLE to RINGING when it rings, to OFFHOOK when it's answered, to IDLE when its hung up
    Outgoing call-  goes from IDLE to OFFHOOK when it dials out, to IDLE when hung up*/
    public void onCallStateChanged(Context context, int state, String number) {

        CallRecorder callRecorder = new CallRecorder(context);
        switch (state) {
            case TelephonyManager.CALL_STATE_RINGING:
                Log.e("IN BC", "In ringging state");
                break;
            case TelephonyManager.CALL_STATE_OFFHOOK:
                //Transition of ringing->offhook are pickups of incoming calls.  Nothing done on them
                if (isIncomming) {
                    callRecorder.onCallStarted(number, true);
                } else {
                    callRecorder.onCallStarted(number, false);
                }
                break;
            case TelephonyManager.CALL_STATE_IDLE:
                //Went to idle-  this is the end of a call.  What type depends on previous state(s)
                if (isIncomming) {
                    //Ring but no pickup-  a miss
                    callRecorder.onCallEnded();
                } else {
                    callRecorder.onCallEnded();
                }
                break;
        }

    }


}
