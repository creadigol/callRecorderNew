package com.creadigol.callrecorder;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.creadigol.callrecorder.Utils.PreferenceSettings;

/**
 * Created by ravi on 24-10-2016.
 */

public class Notification_activity extends AppCompatActivity implements View.OnClickListener {
    Switch sw_call,sw_image,sw_record;
    PreferenceSettings mPreferenceSettings;
    ImageView sw_newcall, sw_showimage, sw_aftercall;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        mPreferenceSettings=new PreferenceSettings(Notification_activity.this);
  /*      sw_call=(Switch)findViewById(R.id.sw_newcall);
        sw_image=(Switch)findViewById(R.id.sw_showimage);
        sw_record=(Switch)findViewById(R.id.sw_aftercall);*/
        sw_newcall = (ImageView) findViewById(R.id.switch_newcall);
        sw_showimage = (ImageView) findViewById(R.id.switch_image);
        sw_aftercall = (ImageView) findViewById(R.id.switch_aftercall);
        sw_newcall.setOnClickListener(this);
        sw_showimage.setOnClickListener(this);
        sw_aftercall.setOnClickListener(this);
        toolbar();
        selectswich();
    }
    public void toolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_notification);
        setSupportActionBar(toolbar);
        TextView tv_toolbar=(TextView)toolbar.findViewById(R.id.tv_toolbar_name);
        tv_toolbar.setText(getResources().getString(R.string.Notification));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    public  void selectswich()
    {
      /* if(mPreferenceSettings.getNotifyNewCall()){
            sw_call.setChecked(true);
        }
        if(mPreferenceSettings.getSHOW_IMAGE_NOTIFY()){
            sw_image.setChecked(true);
        }
        if(mPreferenceSettings.getNotifyAfterCall()){
            sw_record.setChecked(true);
        }*/
        if (mPreferenceSettings.getNotifyNewCall()) {
            sw_newcall.setImageResource(R.drawable.on_switch);
        } else if (mPreferenceSettings.getNotifyNewCall() == false) {
            sw_newcall.setImageResource(R.drawable.off_switch);
        }
        if (mPreferenceSettings.getSHOW_IMAGE_NOTIFY()) {
            sw_showimage.setImageResource(R.drawable.on_switch);
        } else if (mPreferenceSettings.getSHOW_IMAGE_NOTIFY() == false) {
            sw_showimage.setImageResource(R.drawable.off_switch);
        }
        if (mPreferenceSettings.getNotifyAfterCall()) {
            sw_aftercall.setImageResource(R.drawable.on_switch);
        } else if (mPreferenceSettings.getNotifyAfterCall() == false) {
            sw_aftercall.setImageResource(R.drawable.off_switch);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();

                break;
        }
        return true;
    }
  /*  public void onSwitchClicked(View view) {
        switch (view.getId()) {
            case R.id.sw_newcall:
                if (sw_call.isChecked()) {
                    mPreferenceSettings.setNotifyNewCall(true);
                } else {
                    mPreferenceSettings.setNotifyNewCall(false);
                }
                break;
            case R.id.sw_showimage:
                if (sw_image.isChecked()) {
                    mPreferenceSettings.setSHOW_IMAGE_NOTIFY(true);
                } else {
                    mPreferenceSettings.setSHOW_IMAGE_NOTIFY(false);
                }
                break;
            case R.id.sw_aftercall:
                if(sw_record.isChecked()){
                    mPreferenceSettings.setNotifyAfterCall(true);
                }else
                {
                    mPreferenceSettings.setNotifyAfterCall(false);
                }
                break;
        }
    }*/

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.switch_newcall:
                if(mPreferenceSettings.getNotifyNewCall()){
                    mPreferenceSettings.setNotifyNewCall(false);
                    sw_newcall.setImageResource(R.drawable.off_switch);
                }else if(mPreferenceSettings.getNotifyNewCall()==false){
                    mPreferenceSettings.setNotifyNewCall(true);
                    sw_newcall.setImageResource(R.drawable.on_switch);
                }
                break;
            case R.id.switch_image:
                if(mPreferenceSettings.getSHOW_IMAGE_NOTIFY()){
                    mPreferenceSettings.setSHOW_IMAGE_NOTIFY(false);
                    sw_showimage.setImageResource(R.drawable.off_switch);
                }else if(mPreferenceSettings.getSHOW_IMAGE_NOTIFY()==false){
                    mPreferenceSettings.setSHOW_IMAGE_NOTIFY(true);
                    sw_showimage.setImageResource(R.drawable.on_switch);
                }
                break;
            case R.id.switch_aftercall:
                if(mPreferenceSettings.getNotifyAfterCall()){
                    mPreferenceSettings.setNotifyAfterCall(false);
                    sw_aftercall.setImageResource(R.drawable.off_switch);
                }else if(mPreferenceSettings.getNotifyAfterCall()==false){
                    mPreferenceSettings.setNotifyAfterCall(true);
                    sw_aftercall.setImageResource(R.drawable.on_switch);
                }
                break;
        }
    }

}
