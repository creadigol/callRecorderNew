package com.creadigol.callrecorder.Utils;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

import com.creadigol.callrecorder.R;
import com.creadigol.callrecorder.views.RemoteControlWidget;

/**
 * Created by Vj on 12/23/2016.
 */

public class CustomNotification {

    Context context;
    private static int NOTIFICATION_ID = 10000;

    public CustomNotification(Context context) {
        this.context = context;
    }

    public void sendNotification(boolean isOngoing, boolean isNeedAction, String title, String subtitle, String number, boolean isIncoming, boolean isCancel) {
        NotificationCompat.Builder builder = buildNotification(isOngoing, isNeedAction, title, subtitle, number, isIncoming);
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
        Notification notification = builder.build();
        if (!isCancel)
            notificationManager.notify(NOTIFICATION_ID, notification);
        else
            notificationManager.cancel(NOTIFICATION_ID);
    }

    protected NotificationCompat.Builder buildNotification(boolean isOngoing, boolean isNeedAction, String title, String subtitle, String number, boolean isIncoming) {

        // Open NotificationView.java Activity
        Intent intent = new Intent();

        PendingIntent pIntent = PendingIntent.getActivity(
                context,
                01, //NOTIFICATION_ID,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
                // Set Icon
                .setSmallIcon(R.drawable.icone)
                // Set Ticker Message
                //.setTicker(context.getString(R.string.customnotificationticker))

                // Set PendingIntent into Notification
                .setContentIntent(pIntent);

        if (isOngoing) {
            builder.setOngoing(isOngoing);
            // Dismiss Notification
            builder.setAutoCancel(!isOngoing);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            // build a complex notification, with buttons and such
            //
            builder = builder.setContent(getComplexNotificationView(isNeedAction, title, subtitle, number, isIncoming));
        } else {
            // Build a simpler notification, without buttons
            //  TODO set notification without button
            builder = builder.setContentTitle(context.getResources().getString(R.string.app_name))
                    .setContentText("ContentText")
                    .setSmallIcon(android.R.drawable.ic_menu_gallery);
        }
        return builder;
    }

    private RemoteControlWidget getComplexNotificationView(boolean isNeedAction, String title, String subtitle, String number, boolean isIncoming) {
        // Using RemoteViews to bind custom layouts into Notification
        RemoteControlWidget notificationView = new RemoteControlWidget(context,
                context.getPackageName(),
                R.layout.notification_layout, isNeedAction, number, isIncoming
        );

//        // Locate and set the Image into customnotificationtext.xml ImageViews
//        notificationView.setImageViewResource(
//                R.id.imagenotileft,
//                R.mipmap.ic_launcher);

        // Locate and set the Text into customnotificationtext.xml TextViews
        notificationView.setTextViewText(R.id.tv_title, title);
        notificationView.setTextViewText(R.id.tv_sub_title, subtitle);

        return notificationView;
    }

}
