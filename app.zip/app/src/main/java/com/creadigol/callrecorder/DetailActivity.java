package com.creadigol.callrecorder;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;

import de.hdodenhof.circleimageview.CircleImageView;
import com.creadigol.callrecorder.database.DatabaseHelper;

/**
 * Created by ADMIN on 17-Oct-16.
 */

public class DetailActivity extends AppCompatActivity implements View.OnClickListener {
    public String imagePath;
    LinearLayout playLayout;
    Integer CallerId;
    TextView callingNumber, callingTime ,txt_subject;
    String callingNumberr, recordingPath, callingnumber, save, contactName;
    LinearLayout editCallNotes, logdelete, share, call, callHistory, addToContact, savecalles;
    DatabaseHelper databaseHelper;
    Context context;
    CircleImageView profile_image;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calldetail);
        findViewById();
        bindListener();
        Intent i = getIntent();
//        Toast.makeText(this, "hi" + i.getStringExtra("recordingPath"), Toast.LENGTH_SHORT).show();
        recordingPath = i.getStringExtra("recordingPath").toString();
        save = i.getStringExtra("save").toString();
        CallerId = i.getIntExtra("CallerId", 0);
        callingNumberr = i.getStringExtra("callingNumber");
        imagePath = i.getStringExtra("contactImage");
        contactName = i.getStringExtra("contactName");
        callingTime.setText(i.getStringExtra("Callerdate"));


        if (contactName != null) {
            callingNumber.setText(contactName);
        } else {
            callingNumber.setText(i.getStringExtra("callingNumber"));
        }

        if (save != null) {
            if (save.equalsIgnoreCase("true")) {
                savecalles.setVisibility(View.GONE);
            } else {
                savecalles.setVisibility(View.VISIBLE);
            }
        }
        Toolbar();
        if (imagePath != null) {
            if (getContactBitmapFromURI(context, Uri.parse(imagePath)) != null) {
                profile_image.setImageBitmap(getContactBitmapFromURI(context, Uri.parse(imagePath)));
            }
        }

        String sub = databaseHelper.getContactSubject(CallerId);

        if(sub != null){
            txt_subject.setText(sub);
        }
        Log.e("details", "path " + recordingPath + " id " + CallerId + " number " + i.getStringExtra("callingNumber") + " date" + i.getStringExtra("Callerdate") + "");
    }

    public void findViewById() {
        playLayout = (LinearLayout) findViewById(R.id.playLayout);
        callingTime = (TextView) findViewById(R.id.callingTime);
        txt_subject = (TextView) findViewById(R.id.txt_subject);
        callingNumber = (TextView) findViewById(R.id.callingNumber);
        editCallNotes = (LinearLayout) findViewById(R.id.editCallNotes);
        logdelete = (LinearLayout) findViewById(R.id.logdelete);
        share = (LinearLayout) findViewById(R.id.share);
        call = (LinearLayout) findViewById(R.id.call);
        savecalles = (LinearLayout) findViewById(R.id.savecalles);
        callHistory = (LinearLayout) findViewById(R.id.callHistory);
        addToContact = (LinearLayout) findViewById(R.id.addToContact);
        profile_image = (CircleImageView) findViewById(R.id.profile_image);
        databaseHelper = new DatabaseHelper(DetailActivity.this);
    }

    private void bindListener() {
        call.setOnClickListener(this);
        addToContact.setOnClickListener(this);
        logdelete.setOnClickListener(this);
        share.setOnClickListener(this);
        callHistory.setOnClickListener(this);
        editCallNotes.setOnClickListener(this);
        playLayout.setOnClickListener(this);
        savecalles.setOnClickListener(this);

    }

    public Bitmap getContactBitmapFromURI(Context context, Uri uri) {
        InputStream input = null;
        try {
            input = getContentResolver().openInputStream(uri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if (input == null) {
            return null;
        }
        return BitmapFactory.decodeStream(input);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            finish(); // close this activity and return to preview activity (if there is any)
        }

        return super.onOptionsItemSelected(item);
    }

    public void callLog() {
        Intent showCallLog = new Intent();
        showCallLog.setAction(Intent.ACTION_VIEW);
        showCallLog.setType(CallLog.Calls.CONTENT_TYPE);
        startActivity(showCallLog);
    }

    public void CampusSafClick(View view) {
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse(callingnumber));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        startActivity(callIntent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        String sub = databaseHelper.getContactSubject(CallerId);
        if(sub != null){
            txt_subject.setText(sub);
        }
    }

    public void Toolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.appbar_details);
        setSupportActionBar(toolbar);
        TextView tvCatTitle = (TextView) toolbar.findViewById(R.id.tv_toolbar_name);
        if (contactName != null) {
            tvCatTitle.setText(contactName);
        } else {
            tvCatTitle.setText(callingNumberr);
        }
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void shareWhatsapp() {
        try {
//            Drawable mDrawable = imageviewData.getDrawable();
//            Bitmap mBitmap = ((BitmapDrawable) mDrawable).getBitmap();
//            Bitmap workingBitmap = Bitmap.createBitmap(mBitmap);
//            Bitmap mutableBitmap = workingBitmap.copy(Bitmap.Config.ARGB_8888, true);
//            Canvas canvas = new Canvas(mutableBitmap);

//
//            String path = MediaStore.Images.Media.insertImage(getContentResolver(), mBitmap, "Image Description", null);
//            Uri uri = Uri.parse(path);

            Intent share = new Intent(android.content.Intent.ACTION_SEND);
            share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);

            // Add data to the intent, the receiving app will decide
            // what to do with it.

            share.putExtra(Intent.EXTRA_TEXT, "Name:");
            share.setType("audio/*");
//            share.setClassName("com.android.mp3", "example.com.callrecorder");
            final File file1 = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), recordingPath);
            Uri uri = Uri.fromFile(file1);
            share.putExtra(Intent.EXTRA_STREAM, uri);


            startActivity(Intent.createChooser(share, "Share link!"));
        } catch (Exception e) {
//            Toast.makeText(getApplicationContext(), "Wait for download image", Toast.LENGTH_SHORT).show();
        }
    }

    private void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(DetailActivity.this);
        builder.setTitle("Are you sure you want to delete!");
//        builder.setMessage(getString(R.string.dialog_message));

        String positiveText = getString(android.R.string.ok);
        builder.setPositiveButton(positiveText,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // positive button logic
                        databaseHelper.deleteItem(CallerId);
                        Toast.makeText(DetailActivity.this, "Delete Succesfully", Toast.LENGTH_SHORT).show();
                        MainActivity.deleteFlag = true;
                        finish();
                    }
                });

        String negativeText = getString(android.R.string.cancel);
        builder.setNegativeButton(negativeText,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // negative button logic
                        dialog.dismiss();
                    }
                });

        AlertDialog dialog = builder.create();
        // display dialog
        dialog.show();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.playLayout:

                File file = new File(recordingPath);

                if(!file.exists()){
                    Toast.makeText(this, getResources().getString(R.string.RecordingNotFound), Toast.LENGTH_LONG).show();
                    return;
                }
                file = null;
                Intent intent = new Intent(DetailActivity.this, PlayActivityNew.class);
                intent.putExtra("path", recordingPath);
                intent.putExtra("number", callingNumberr);
                intent.putExtra("imagePath", imagePath);
                intent.putExtra("contactName", contactName);
                intent.putExtra("callerId", CallerId);
                startActivity(intent);
                break;
            case R.id.editCallNotes:
                Intent i = new Intent(getApplicationContext(), Editnotes_activity.class);
                i.putExtra("callerId", CallerId);
                startActivity(i);
                break;
            case R.id.logdelete:
                showAlertDialog();
                break;
            case R.id.share:
                final Intent shareIntent = new Intent(android.content.Intent.ACTION_SEND);
                shareIntent.setType("audio/*");
                shareIntent.putExtra(android.content.Intent.EXTRA_STREAM, Uri.parse("file://" + recordingPath));
                startActivity(Intent.createChooser(shareIntent, "callrecorder"));
                break;
            case R.id.call:
//                callLog();
                callLog1();
                break;
            case R.id.callHistory:
                Intent i2 = new Intent(getApplicationContext(), CallHistory.class);
                i2.putExtra("callingNumber", callingNumberr);
                startActivity(i2);
                break;
            case R.id.addToContact:
                Intent add = new Intent(
                        ContactsContract.Intents.SHOW_OR_CREATE_CONTACT,
                        Uri.parse("tel:" + callingNumberr));
                add.putExtra(ContactsContract.Intents.EXTRA_FORCE_CREATE, true);
                startActivity(add);
                break;
            case R.id.savecalles:

                databaseHelper.UpdatesaveStatus(CallerId, "true");
                MainActivity.SaveFlag = true;
                MainActivity.deleteFlag = true;
                finish();

                break;
        }
    }

    public void callLog1() {
//        Intent showCallLog = new Intent();
//        showCallLog.setAction(Intent.ACTION_VIEW);
//        showCallLog.setType(CallLog.Calls.CONTENT_TYPE);
//        startActivity(showCallLog);
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + callingNumberr));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        startActivity(intent);
    }
}
  /*  final View.OnClickListener click_listener = new View.OnClickListener() {
        public void onClick(final View v) {
            if (v == playLayout) {

            }

            if (v == editCallNotes) {
                Intent i = new Intent(getApplicationContext(), Editnotes_activity.class);
                startActivity(i);
                // Toast.makeText(getApplicationContext(),"On notes",Toast.LENGTH_SHORT).show();
            }
            if (v == logdelete) {
//            Intent i = new Intent(getApplicationContext(),MainActivity.class);
//            startActivity(i);
                showLocationDialog();


            }
            if (v == share) {
//            Intent i = new Intent(getApplicationContext(),MainActivity.class);
//            startActivity(i);
                final Intent shareIntent = new Intent(android.content.Intent.ACTION_SEND);
                shareIntent.setType("audio*//*");
                shareIntent.putExtra(android.content.Intent.EXTRA_STREAM, Uri.parse("file://" + recordingPath));

                startActivity(Intent.createChooser(shareIntent, "callrecorder"));

//                shareWhatsapp();
            }
            if (v == call) {
                callLog();
//                CampusSafClick(v);

            }
            if (v == callHistory) {
//            Intent i = new Intent(getApplicationContext(),MainActivity.class);
//            startActivity(i);
            }
            if (v == addToContact) {
                Intent intent = new Intent(
                        ContactsContract.Intents.SHOW_OR_CREATE_CONTACT,
                        Uri.parse("tel:" + callingNumberr));

                intent.putExtra(ContactsContract.Intents.EXTRA_FORCE_CREATE, true);
                startActivity(intent);
//            Intent i = new Intent(getApplicationContext(),MainActivity.class);
//            startActivity(i);
            }
        }
    };*/