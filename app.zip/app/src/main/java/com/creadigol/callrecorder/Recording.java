package com.creadigol.callrecorder;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import com.creadigol.callrecorder.Utils.Constants;
import com.creadigol.callrecorder.Utils.PreferenceSettings;

/**
 * Created by ravi on 24-10-2016.
 */

public class Recording extends AppCompatActivity implements View.OnClickListener, SeekBar.OnSeekBarChangeListener {

    LinearLayout layout_audio_source, ll_audio_formate, ll_delay;
    PreferenceSettings pref;
    RadioButton radioButton;
    TextView txt_audioformate;
    Switch mySwitchspeaker, mySwitchbluetooth, mySwitchvolume;
    String speaker = "true";
    String speaker2 = "false";
    //String tmp, a;
    public static String in;
    public static String out;
    public static int in2;
    public static int out2;
    AudioManager audioManager;
    ImageView sw_speaker, sw_bluethooth;
    Context context;
    String s_speaker = "true", s_bluethooth = "true";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recording);
        pref = new PreferenceSettings(Recording.this);
        findViewById();
        toolbar();
        selectswich();
    }
/*
        mySwitchspeaker.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                audioManager.setMode(AudioManager.MODE_IN_CALL);
                //    audioManager.setMode(AudioManager.MODE_NORMAL);
                audioManager.setSpeakerphoneOn(true);

                if (isChecked) {
                    pref.setRecordingSpeaker(speaker);
                    tmp = pref.getRecordingSpeaker();
                    System.out.println("Prefrence temp value : " + tmp);
                } else {
                    pref.setRecordingSpeaker(speaker2);
                    tmp = pref.getRecordingSpeaker();

                }
            }
        });


        mySwitchbluetooth.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    Log.e("Hiiii", "heeeeee");
                    pref.setRecordingBluetooth(speaker);
                    Log.e("value", "Bluetooth" + pref.getRecordingBluetooth());
                    System.out.println("Bluettoooo" + pref.getRecordingBluetooth());

                } else {
                    pref.setRecordingBluetooth(speaker2);
                    Log.e("value 2", "Bluetooth" + pref.getRecordingBluetooth());

                }
            }
        });


    }
*/

    private void findViewById() {
        layout_audio_source = (LinearLayout) findViewById(R.id.ll_source);
        ll_audio_formate = (LinearLayout) findViewById(R.id.ll_audio_formate);
        ll_delay = (LinearLayout) findViewById(R.id.ll_delay);
        txt_audioformate = (TextView) findViewById(R.id.txt_audioformate);
        layout_audio_source.setOnClickListener(this);
        ll_audio_formate.setOnClickListener(this);
        ll_delay.setOnClickListener(this);
//        mySwitchspeaker = (Switch) findViewById(R.id.mySwitchspeaker);
//        mySwitchbluetooth = (Switch) findViewById(R.id.mySwitchbluetooth);
        mySwitchvolume = (Switch) findViewById(R.id.mySwitchvolume);
        sw_speaker = (ImageView) findViewById(R.id.switch_speaker);
        sw_bluethooth = (ImageView) findViewById(R.id.switch_bluetooth);
        sw_speaker.setOnClickListener(this);
        sw_bluethooth.setOnClickListener(this);
    }

    public void selectswich() {
/*        if(pref.getRecordingBluetooth().equalsIgnoreCase("true")){
            mySwitchbluetooth.setChecked(true);
        }
        if(pref.getRecordingSpeaker().equalsIgnoreCase("true")){
            mySwitchspeaker.setChecked(true);
        }*/
        if (pref.getRecordingBluetooth().equalsIgnoreCase("true")) {
            sw_bluethooth.setImageResource(R.drawable.on_switch);
        } else if (pref.getRecordingBluetooth().equalsIgnoreCase("false")) {
            sw_bluethooth.setImageResource(R.drawable.off_switch);

        }
        if (pref.getRecordingSpeaker().equalsIgnoreCase("true")) {
            sw_speaker.setImageResource(R.drawable.on_switch);
        } else if (pref.getRecordingSpeaker().equalsIgnoreCase("false")) {
            sw_speaker.setImageResource(R.drawable.off_switch);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        setAudioFormateValue();
    }

    public void setAudioFormateValue() {
         /*if (pref.getAudioFormat() == Constants.MP\\) {
            txt_audioformate.setText("MP3");
        } else */
        if (pref.getAudioFormat() == Constants.AUDIO_FORMAT_3GP) {
            txt_audioformate.setText("3GP");
        } else if (pref.getAudioFormat() == Constants.AUDIO_FORMAT_MP4) {
            txt_audioformate.setText("MP4");
        } else if (pref.getAudioFormat() == Constants.AUDIO_FORMAT_AMR) {
            txt_audioformate.setText("AMR");
        } else if (pref.getAudioFormat() == Constants.AUDIO_FORMAT_FLAC) {
            txt_audioformate.setText("FLAC");
        } else if (pref.getAudioFormat() == Constants.AUDIO_FORMAT_WAV) {
            txt_audioformate.setText("WAV");
        }
    }

    private void openAudioSource() {
        final Dialog dialog = new Dialog(Recording.this);
        dialog.setContentView(R.layout.dialog_recordingsource);
        dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        TextView cancel_dialog = (TextView) dialog.findViewById(R.id.cancel_dialog);
        cancel_dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        // if button is clicked, close the custom dialog
        dialog.show();
    }

    /*private void openAudioformate() {
        final Dialog dialog = new Dialog(Recording.this);
        dialog.setContentView(R.layout.dialog_audioformate);
        dialog.setTitle("Audio Format");
        RadioGroup rg_group = (RadioGroup) dialog.findViewById(R.id.rgformat);
        Button btn_cancel = (Button) dialog.findViewById(R.id.btn_cancel);

        rg_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                @Override
                                                public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                    radioButton = (RadioButton) dialog.findViewById(checkedId);
                                                    a = (String) radioButton.getText();
                                                    pref.setAudioFormat(a);
                                                    //  Toast.makeText(getApplicationContext(), pref.setAudioFormat(a), Toast.LENGTH_SHORT).show();
                                                }
                                            }
        );
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
//                pref.getAudioFormat();
//                Log.e("Value of log",pref.getAudioFormat());
            }
        });
        dialog.show();
    }*/
    private void openAudioformate() {
        final Dialog dialog = new Dialog(Recording.this);
        dialog.setContentView(R.layout.dialog_audioformate);
        dialog.setTitle(getResources().getString(R.string.Audioformate));
        RadioGroup rg_group = (RadioGroup) dialog.findViewById(R.id.rgformat);
        TextView btn_cancel = (TextView) dialog.findViewById(R.id.txt_cancel);
        RadioButton rd_mp3, rd_3gp, rd_amr, rd_mpg, rd_flac, rd_wav;

//        rd_mp3 = (RadioButton) dialog.findViewById(R.id.rd_mp3);
        rd_3gp = (RadioButton) dialog.findViewById(R.id.rd_3gp);
        rd_3gp.setTag(Integer.valueOf(Constants.AUDIO_FORMAT_3GP));
        rd_amr = (RadioButton) dialog.findViewById(R.id.rd_amr);
        rd_amr.setTag(Integer.valueOf(Constants.AUDIO_FORMAT_AMR));
        rd_mpg = (RadioButton) dialog.findViewById(R.id.rd_mpg);
        rd_mpg.setTag(Integer.valueOf(Constants.AUDIO_FORMAT_MP4));
        rd_flac = (RadioButton) dialog.findViewById(R.id.rd_flac);
        rd_flac.setTag(Integer.valueOf(Constants.AUDIO_FORMAT_FLAC));
        rd_wav = (RadioButton) dialog.findViewById(R.id.rd_wav);
        rd_wav.setTag(Integer.valueOf(Constants.AUDIO_FORMAT_WAV));


        /*if (pref.getAudioFormat().equalsIgnoreCase("4")) {
            rd_mp3.setChecked(true);
        } else */
        if (pref.getAudioFormat() == Constants.AUDIO_FORMAT_3GP) {
            rd_3gp.setChecked(true);
        } else if (pref.getAudioFormat() == Constants.AUDIO_FORMAT_MP4) {
            rd_mpg.setChecked(true);
        } else if (pref.getAudioFormat() == Constants.AUDIO_FORMAT_AMR) {
            rd_amr.setChecked(true);
        } else if (pref.getAudioFormat() == Constants.AUDIO_FORMAT_FLAC) {
            rd_flac.setChecked(true);
        } else if (pref.getAudioFormat() == Constants.AUDIO_FORMAT_WAV) {
            rd_wav.setChecked(true);
        }

        rg_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                @Override
                                                public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                    radioButton = (RadioButton) dialog.findViewById(checkedId);
                                                    int keyFormat = (Integer) radioButton.getTag();
                                                    //a = (String) radioButton.getText();
                                                    //if (a.equalsIgnoreCase("mp3")) {
                                                    pref.setAudioFormat(keyFormat);
                                                    setAudioFormateValue();
                                                    dialog.dismiss();
                                                    //  Toast.makeText(getApplicationContext(), pref.setAudioFormat(a), Toast.LENGTH_SHORT).show();
                                                }
                                            }
        );
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }


    public void toolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_recording);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.Recording));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();

                break;
        }
        return true;
    }

    /* private void delayDialog() {
         final Dialog dialog = new Dialog(Recording.this);
         dialog.setContentView(R.layout.dialog_recording_delay);
         TextView incoming_values = (TextView) dialog.findViewById(R.id.incoming_value);
         TextView outgoing_values = (TextView) dialog.findViewById(R.id.outgoing_values);
         SeekBar seek_incoming = (SeekBar) dialog.findViewById(R.id.seek_incoming);
         SeekBar seek_outgoing = (SeekBar) dialog.findViewById(R.id.seek_outgoing);
         // dialog.setTitle("Audio");
         dialog.show();

         seek_incoming.setOnSeekBarChangeListener(this);
         seek_outgoing.setOnSeekBarChangeListener(this);
     }*/
    private void delayDialog() {
        final Dialog dialog = new Dialog(Recording.this);
        dialog.setContentView(R.layout.dialog_recording_delay);
        dialog.setTitle(getResources().getString(R.string.Delay));
        final SeekBar seek_incoming = (SeekBar) dialog.findViewById(R.id.seek_incoming);
        final SeekBar seek_outgoing = (SeekBar) dialog.findViewById(R.id.seek_outgoing);


        final TextView txt_incoming = (TextView) dialog.findViewById(R.id.incoming_value);
        final TextView txt_outgoing = (TextView) dialog.findViewById(R.id.outgoing_values);

        Button btnok = (Button) dialog.findViewById(R.id.ok);
        Button btnreset = (Button) dialog.findViewById(R.id.reset);

//        in2=pref.getDelayIncoming();
//        out2=pref.getDelayOutgoing();

        in2 = Integer.parseInt(pref.getDelayIncoming());
        out2 = Integer.parseInt(pref.getDelayOutgoing());
        seek_incoming.setProgress(in2);
        seek_outgoing.setProgress(out2);
        txt_incoming.setText(String.valueOf(in2) + " Sec");
        txt_outgoing.setText(String.valueOf(out2) + " Sec");


        seek_incoming.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // TODO Auto-generated method stub
                txt_incoming.setText(String.valueOf(progress));
                in = (String) txt_incoming.getText();

                pref.setDelayIncoming(in);
                txt_incoming.setText(in + " Sec");

                System.out.println("Oncoming value" + in);
                // seek_incoming.setProgress(Integer.parseInt(in2));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }
        });


        seek_outgoing.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                // TODO Auto-generated method stub
                txt_outgoing.setText(String.valueOf(progress));
                out = (String) txt_outgoing.getText();
                pref.setDelayOutgoing(out);
                txt_outgoing.setText(out + " Sec");
                // seek_outgoing.setProgress(Integer.parseInt(out2));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }
        });

        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//               pref.setDelayOutgoing(out);
//               pref.setDelayIncoming(in);
                dialog.dismiss();
            }
        });

        btnreset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                seek_incoming.setProgress(3);
                seek_outgoing.setProgress(10);
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_source:
//                openAudioSource();
                break;
            case R.id.ll_audio_formate:
                openAudioformate();
                break;
            case R.id.ll_delay:
                delayDialog();
                break;
            case R.id.switch_speaker:
                if (s_speaker.equalsIgnoreCase("true")) {
                    s_speaker = "false";
                    pref.setRecordingSpeaker("false");
                    sw_speaker.setImageResource(R.drawable.off_switch);
                } else if (s_speaker.equalsIgnoreCase("false")) {
                    s_speaker = "true";
                    pref.setRecordingSpeaker("true");
                    sw_speaker.setImageResource(R.drawable.on_switch);
                }
                break;
            case R.id.switch_bluetooth:
                audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                audioManager.setMode(AudioManager.MODE_IN_CALL);
                //    audioManager.setMode(AudioManager.MODE_NORMAL);
                audioManager.setSpeakerphoneOn(true);

                if (s_bluethooth.equalsIgnoreCase("true")) {
                    s_bluethooth = "false";
                    pref.setRecordingBluetooth("false");
                    sw_bluethooth.setImageResource(R.drawable.off_switch);
                } else if (s_bluethooth.equalsIgnoreCase("false")) {
                    s_bluethooth = "true";
                    pref.setRecordingBluetooth("true");
                    sw_bluethooth.setImageResource(R.drawable.on_switch);
                }
                break;
        }

    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}

