package com.creadigol.callrecorder.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import com.creadigol.callrecorder.Model.ContactModel;
import com.creadigol.callrecorder.R;

public class RecordcontactAdapter extends RecyclerView.Adapter<ViewHolder> {


	private static Context context;
	ArrayList<ContactModel> contactModels;
	OnClickListener onClickListener;

	public RecordcontactAdapter(Context context, ArrayList<ContactModel> contactModels, OnClickListener onClickListener) {
		// TODO Auto-generated constructor stub
		this.context = context;
		this.contactModels = contactModels;
		this.onClickListener=onClickListener;
	}

	@Override
	public int getItemCount() {
		// TODO Auto-generated method stub
		return contactModels.size();
//		return 4;
	}

	@Override
	public void onBindViewHolder(ViewHolder viewHolder,
			final int position) {
		// TODO Auto-generated method stub
		final TextFeedViewHolder holder = (TextFeedViewHolder) viewHolder;

		holder.name.setText(contactModels.get(position).getContactname());
		holder.number.setText(contactModels.get(position).getContactnumber());
//		Toast.makeText(context, "name"+contactModels.get(position).getContactname(), Toast.LENGTH_SHORT).show();
//		Toast.makeText(context, "number"+contactModels.get(position).getContactnumber(), Toast.LENGTH_SHORT).show();

		holder.linearLayout.setTag(position);
		holder.linearLayout.setOnClickListener(onClickListener);
	}

	@Override
	public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
		// TODO Auto-generated method stub

		final View view = LayoutInflater.from(context).inflate(
				R.layout.custome_recordcontact_layout, parent, false);

		final TextFeedViewHolder textFeedViewHolder = new TextFeedViewHolder(
				view);

		return textFeedViewHolder;

	}

	public static class TextFeedViewHolder extends ViewHolder {
		TextView number,name;
		LinearLayout linearLayout;

		public TextFeedViewHolder(View view) {
			super(view);

			number = (TextView) view.findViewById(R.id.ignorenumber);
			name = (TextView) view.findViewById(R.id.ignorename);
			linearLayout=(LinearLayout)view.findViewById(R.id.ll_ignore);
		}
	}
}
